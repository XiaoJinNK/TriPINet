from utils.tools import split_dataset, generate_trainval_dataloaders, read_txt
from config import Dataset_Path

dp = Dataset_Path()

"""
train: 4500  val:122  test: 501
"""
imgs = read_txt(dp.CASIAv2_SP_img_txt)
masks = read_txt(dp.CASIAv2_SP_mask_txt)
a, b, c = split_dataset(imgs, masks, data_nums=(1828 - 122 - 501, 122, 501), save_split_path='.')

imgs = read_txt(dp.CASIAv2_CM_img_txt)
masks = read_txt(dp.CASIAv2_CM_mask_txt)
with open('train_img.txt', 'a') as f:
    for img in imgs:
        f.write(img + '\n')
with open('train_mask.txt', 'a') as f:
    for mask in masks:
        f.write(mask + '\n')