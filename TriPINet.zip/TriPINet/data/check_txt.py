import os
from utils.tools import read_txt

split_dir = 'CASIAv2'
train_img = read_txt(os.path.join(split_dir, 'train_img.txt'))
val_img = read_txt(os.path.join(split_dir, 'val_img.txt'))
test_img = read_txt(os.path.join(split_dir, 'test_img.txt'))

# val in train
for i in val_img:
    if i in train_img:
        print('val img in train img')
        break

# test in train
for i in test_img:
    if i in train_img:
        print('test img in train img')
        break

# test in val
for i in test_img:
    if i in val_img:
        print('test img in val img')
        break