from utils.tools import split_dataset, generate_trainval_dataloaders, read_txt
from config import Dataset_Path

dp = Dataset_Path()

"""
train: 70  val:10  test: 20
"""
imgs = read_txt(dp.Carvalho_img_txt)
masks = read_txt(dp.Carvalho_mask_txt)
_ = split_dataset(imgs, masks, data_nums=(70, 10, 20), save_split_path='.')