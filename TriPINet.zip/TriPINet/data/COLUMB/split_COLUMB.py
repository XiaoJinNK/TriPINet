from utils.tools import split_dataset, generate_trainval_dataloaders, read_txt
from config import Dataset_Path

dp = Dataset_Path()

"""
train: 125  val:5  test: 50
"""
imgs = read_txt(dp.COLUMB_img_txt)
masks = read_txt(dp.COLUMB_mask_txt)
_ = split_dataset(imgs, masks, data_nums=(125, 5, 50), save_split_path='.')
