from utils.tools import split_dataset, generate_trainval_dataloaders, read_txt
from config import Dataset_Path

dp = Dataset_Path()

"""
train: 341  val:20  test: 100
"""
imgs = read_txt(dp.CASIAv1_SP_modified_txt)
masks = read_txt(dp.CASIAv1_SP_mask_txt)
_ = split_dataset(imgs, masks, data_nums=(341, 20, 100), save_split_path='.')