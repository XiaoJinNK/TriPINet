import sys
import numpy as np
import torch
from utils.tools import get_preds_mask, get_preds_prob_map
from sklearn.metrics import roc_auc_score, average_precision_score


def get_tp(preds_mask, mask):
    assert len(preds_mask.shape) == 3
    assert len(mask.shape) == 3
    return np.logical_and(np.equal(preds_mask, 1), np.equal(mask, 1)).sum(axis=(1, 2))


def get_tn(preds_mask, mask):
    assert len(preds_mask.shape) == 3
    assert len(mask.shape) == 3
    return np.logical_and(np.equal(preds_mask, 0), np.equal(mask, 0)).sum(axis=(1, 2))


def get_fp(preds_mask, mask):
    assert len(preds_mask.shape) == 3
    assert len(mask.shape) == 3
    return np.logical_and(np.equal(preds_mask, 1), np.equal(mask, 0)).sum(axis=(1, 2))


def get_fn(preds_mask, mask):
    assert len(preds_mask.shape) == 3
    assert len(mask.shape) == 3
    return np.logical_and(np.equal(preds_mask, 0), np.equal(mask, 1)).sum(axis=(1, 2))


def get_tp_tn_fp_fn(preds_mask, mask):
    assert len(preds_mask.shape) == 3
    assert len(mask.shape) == 3
    return get_tp(preds_mask, mask), get_tn(preds_mask, mask), get_fp(preds_mask, mask), get_fn(preds_mask, mask)


def AUC(pred_prob_map, mask):
    """
    使用Sklearn包计算ROC曲线下面积AUC。
    Args:
        pred_prob_map: 概率图，为logits经过sigmoid或softmax的结果 (Batch, H, W)
        mask: GT二值图 (Batch, H, W)

    Returns:
        AUC ndarray (Batch,)
    """
    batch_size = pred_prob_map.shape[0]
    auc_arr = np.array([0.] * batch_size)
    pred_prob_map = pred_prob_map.reshape(batch_size, -1)
    mask = mask.reshape(batch_size, -1)
    for i in range(batch_size):
        try:
            auc_arr[i] = roc_auc_score(mask[i], pred_prob_map[i])
        except ValueError:
            auc_arr[i] = 1.0
    return auc_arr


def AP(pred_prob_map, mask):
    """
        使用Sklearn包计算PR曲线下面积AP。
        Args:
            pred_prob_map: 概率图，为logits经过sigmoid或softmax的结果 (Batch, H, W)
            mask: GT二值图 (Batch, H, W)

        Returns:
            AP ndarray (Batch,)
    """
    batch_size = pred_prob_map.shape[0]
    ap_arr = np.array([0.] * batch_size)
    pred_prob_map = pred_prob_map.reshape(batch_size, -1)
    mask = mask.reshape(batch_size, -1)
    for i in range(batch_size):
        try:
            ap_arr[i] = average_precision_score(mask[i], pred_prob_map[i])
        except ValueError:
            ap_arr[i] = 1.0
    return ap_arr


def matthews_correlation_coefficient(confusion_matrix):
    tp, tn, fp, fn = confusion_matrix
    for i in range(tp.shape[0]):
        if tp[i] == 0 and fn[i] == 0:
            tp[i] = tn[i]
            fn[i] = fp[i]
            fp[i] = 0
            tn[i] = 0
    N = tn + tp + fn + fp
    S = (tp + fn) / N
    P = (tp + fp) / N
    mcc_denominator = np.sqrt(P * S * (1 - S) * (1 - P))
    mcc_denominator = np.nan_to_num(mcc_denominator, nan=float('inf'), posinf=float('inf'), neginf=float('-inf'))
    mcc_denominator[mcc_denominator == 0.0] = float('inf')
    mcc = (tp / N - S * P) / mcc_denominator
    return np.nan_to_num(mcc)


def f1_score(confusion_matrix):
    tp, tn, fp, fn = confusion_matrix
    # 如果mask是全黑负样本
    for i in range(tp.shape[0]):
        if tp[i] == 0 and fn[i] == 0:
            tp[i] = tn[i]
            fn[i] = fp[i]
            fp[i] = 0
            tn[i] = 0

    f1 = 2 * tp / (2 * tp + fp + fn)
    return np.nan_to_num(f1)


def iou_measure(confusion_matrix):
    tp, tn, fp, fn = confusion_matrix
    # 如果mask是全黑负样本
    for i in range(len(tp)):
        if tp[i] == 0 and fn[i] == 0:
            tp[i] = tn[i]
            fn[i] = fp[i]
            fp[i] = 0
            tn[i] = 0

    iou = tp / (tp + fp + fn)
    return np.nan_to_num(iou)


def get_Precision(confusion_matrix):
    tp, _, fp, _ = confusion_matrix
    precision = tp / (tp + fp)
    # if np.isnan(precision).sum():
    #     return np.array([0.] * len(tp))
    # else:
    #     return precision
    return np.nan_to_num(precision)


def get_Recall(confusion_matrix):
    tp, tn, fp, fn = confusion_matrix
    recall = tp / (tp + fn)
    # if np.isnan(recall).sum():
    #     return np.array([0.] * len(tp))
    # else:
    #     return recall
    return np.nan_to_num(recall)

def get_accuracy(confusion_matrix):
    tp, tn, fp, fn = confusion_matrix
    accuracy = (tp + tn) / (tp + tn + fp + fn)
    # if np.isnan(accuracy).sum():
    #     return np.array([0.] * len(tp))
    # else:
    #     return accuracy.numpy()
    return np.nan_to_num(accuracy)


def get_metrics(logits, mask, threshold='best', best_metric='f1'):
    """
    返回 auc, f1, mcc, iou, accuracy, threshold
    输入的 logits 和 mask 必须是(B, 1, H, W)或者(B, H, W)，如果不是则会报错。
    注意：对于真实图片（全黑样本），本方法进行了黑白转换，这样会显著提升指标。实际在计算pixel-level指标时应该忽略掉真实图片，只计算篡改图片的评价指标；计算 image-level 指标时再使用真实图片的结果。

    Args:
        threshold: float or 'best'
        best_metric: "f1" or "mcc" or "iou" or "acc"，当 threshold='best' 时通过哪个评价指标计算最优阈值。此时所有的评价指标都是最优值，只是该参数表示了输入评价指标的最优阈值。
    """
    # 判断 logits 和 mask 的 shape
    if len(mask.shape) == 4:
        if mask.shape[1] == 1:
            mask = mask.reshape(mask.shape[0], mask.shape[2], mask.shape[3])
        else:
            print(f'mask shape {mask.shape} is illegal!')
            sys.exit(1)
    if len(logits.shape) == 4:
        if logits.shape[1] == 1:
            logits = logits.reshape(logits.shape[0], logits.shape[2], logits.shape[3])
        else:
            print(f'logits shape {logits.shape} is illegal!')
            sys.exit(1)

    # 计算AUC and AP，AUC and AP 的计算与二值化pred_prob_map的阈值无关
    auc = AUC(get_preds_prob_map(logits), mask)
    ap = AP(get_preds_prob_map(logits), mask)

    if type(threshold) is not str:
        pred_mask = get_preds_mask(logits, threshold=threshold)
        confusion_matrix = get_tp_tn_fp_fn(pred_mask.cpu(), mask.cpu())
        f1 = f1_score(confusion_matrix)
        mcc = matthews_correlation_coefficient(confusion_matrix)
        iou = iou_measure(confusion_matrix)
        acc = get_accuracy(confusion_matrix)
        p = get_Precision(confusion_matrix)
        r = get_Recall(confusion_matrix)
        return list(auc), list(f1), list(mcc), list(iou), list(acc), list(p), list(r), list(ap), threshold
        # return list(auc), list(f1), list(mcc), list(iou), list(acc), threshold
    elif threshold == 'best':
        threshold_list = np.arange(0.1, 1.0, 0.1)
        f1_list, mcc_list, iou_list, acc_list, p_list, r_list = [], [], [], [], [], []
        for threshold in threshold_list:
            pred_mask = get_preds_mask(logits, threshold=threshold)
            confusion_matrix = get_tp_tn_fp_fn(pred_mask.cpu(), mask.cpu())
            f1 = f1_score(confusion_matrix)
            mcc = matthews_correlation_coefficient(confusion_matrix)
            iou = iou_measure(confusion_matrix)
            acc = get_accuracy(confusion_matrix)
            p = get_Precision(confusion_matrix)
            r = get_Recall(confusion_matrix)
            f1_list.append(list(f1))
            mcc_list.append(list(mcc))
            iou_list.append(list(iou))
            acc_list.append(list(acc))
            p_list.append(list(p))
            r_list.append(list(r))
        f1 = np.max(f1_list, axis=0)
        mcc = np.max(mcc_list, axis=0)
        iou = np.max(iou_list, axis=0)
        acc = np.max(acc_list, axis=0)
        p = np.max(p_list, axis=0)
        r = np.max(r_list, axis=0)

        if best_metric == 'f1':
            best_thresholds = (np.argmax(f1_list, axis=0) + 1) * 0.1
        elif best_metric == 'mcc':
            best_thresholds = (np.argmax(mcc_list, axis=0) + 1) * 0.1
        elif best_metric == 'iou':
            best_thresholds = (np.argmax(iou_list, axis=0) + 1) * 0.1
        elif best_metric == 'acc':
            best_thresholds = (np.argmax(acc_list, axis=0) + 1) * 0.1
        elif best_metric == 'p':
            best_thresholds = (np.argmax(p_list, axis=0) + 1) * 0.1
        elif best_metric == 'r':
            best_thresholds = (np.argmax(r_list, axis=0) + 1) * 0.1
        else:
            print(f'Parameter best_metric = {best_metric} is illegal!\nbest_metric must be one of "f1" or "mcc" or "iou" or "acc" ')
            sys.exit(1)
        return list(auc), list(f1), list(mcc), list(iou), list(acc), list(p), list(r), list(ap), best_thresholds[0]
    else:
        print('Parameter threshold is illegal!')
        sys.exit(1)


if __name__ == '__main__':
    batch_size = 2
    logits = torch.randn(size=(batch_size, 256, 256))
    mask = torch.randint(low=0, high=2, size=(batch_size, 256, 256))

    import time
    t1 = time.time()

    metrics = get_metrics(logits, mask, threshold=0.5)
    print(metrics)
    metrics = get_metrics(logits, mask, threshold='best', best_metric='f1')
    print(metrics)

    t2 = time.time()
    print(t2 - t1, 's')
