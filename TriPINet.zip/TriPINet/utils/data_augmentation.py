import random
import numpy as np
import torch
from PIL import Image
from PIL import ImageEnhance

"""
Data Augumentation:
把所有要同时增强的图片，例如img和mask，放到一个列表里，传入函数。
例子：img, mask = cv_random_flip((img, mask))

传入的img或mask必须是PIL.Image对象。
"""


def random_horizontal_flip(img_list):
    flip_flag = random.randint(0, 1)
    if flip_flag == 1:
        for i in range(len(img_list)):
            img_list[i] = img_list[i].transpose(Image.FLIP_LEFT_RIGHT)
    return img_list


def random_vertical_flip(img_list):
    flip_flag = random.randint(0, 1)
    if flip_flag == 1:
        for i in range(len(img_list)):
            img_list[i] = img_list[i].transpose(Image.FLIP_TOP_BOTTOM)
    return img_list


def randomCrop(img_list):
    border = 30
    image_width = img_list[0].size[0]
    image_height = img_list[0].size[1]
    crop_win_width = np.random.randint(image_width - border, image_width)
    crop_win_height = np.random.randint(image_height - border, image_height)
    random_region = (
        (image_width - crop_win_width) >> 1, (image_height - crop_win_height) >> 1, (image_width + crop_win_width) >> 1,
        (image_height + crop_win_height) >> 1)
    for i in range(len(img_list)):
        img_list[i] = img_list[i].crop(random_region)
    return img_list


def randomRotation(img_list):
    mode = Image.BICUBIC
    if random.random() > 0.8:
        random_angle = np.random.randint(-15, 15)
        for i in range(len(img_list)):
            img_list[i] = img_list[i].rotate(random_angle, mode)
    return img_list


def colorEnhance(image_PIL):
    """
    该方法只需对原图像进行处理，其余标签如mask和edge不需要增强。
    """
    # 亮度
    bright_intensity = random.randint(5, 15) / 10.0
    image_PIL = ImageEnhance.Brightness(image_PIL).enhance(bright_intensity)
    # 对比度
    contrast_intensity = random.randint(5, 15) / 10.0
    image_PIL = ImageEnhance.Contrast(image_PIL).enhance(contrast_intensity)
    # 色度
    color_intensity = random.randint(0, 20) / 10.0
    image_PIL = ImageEnhance.Color(image_PIL).enhance(color_intensity)
    # 锐度
    sharp_intensity = random.randint(0, 30) / 10.0
    image_PIL = ImageEnhance.Sharpness(image_PIL).enhance(sharp_intensity)
    return image_PIL


if __name__ == '__main__':
    import matplotlib.pyplot as plt
    import cv2
    import torchvision.transforms as T
    from utils.tools import binarize_mask

    path = r'D:\Datasets\Forensics-Dataset\DEFACTO\Splicing-annotations-1\donor_mask\2_000000336061.tif'
    img = cv2.imread(path, flags=cv2.IMREAD_GRAYSCALE)
    img[np.where(img < 128)] = 0
    img[np.where(img >= 128)] = 1
    img = Image.fromarray(img).convert('L')

    # path2 = r'D:\Datasets\Forensics-Dataset\DEFACTO\Inpainting-images\img\0_000000000431.tif'
    # img = cv2.imread(path2, flags=cv2.IMREAD_COLOR)
    # img = cv2.cvtColor(img, code=cv2.COLOR_BGR2RGB)
    # img = Image.fromarray(img).convert('RGB')
    # img = randomRotation([img])[0]
    # plt.imshow(img)
    # plt.show()
    print(type(img))
    print(np.unique(img))
    img = T.PILToTensor()(img)
    print(type(img))
    print(torch.unique(img))
