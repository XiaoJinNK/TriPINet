import pickle
import matplotlib.pyplot as plt
import os

os.chdir(os.path.dirname(__file__))

dir1 = r'F:\mine_result'
dir2 = '2022-04-13-3080#1-posw2-skip'
metric_pkl = os.path.join(dir1, dir2, 'result_metrics.pkl')
save_dir = './save_figs'
epochs = 30

os.makedirs(save_dir, exist_ok=True)

with open(metric_pkl,'rb') as f:
    train_loss_list, val_loss_list, \
    train_auc_list, train_f1_list, train_mcc_list, train_iou_list, train_acc_list, \
    val_auc_list, val_f1_list, val_mcc_list, val_iou_list, val_acc_list = pickle.load(f)

# 保存结果图片
plt.figure()
plt.plot(list(range(1, epochs + 1)), train_loss_list, c='b', label='train_loss')
plt.plot(list(range(1, epochs + 1)), val_loss_list, c='y', label='val_loss')
plt.xlabel('epoch')
plt.ylabel('loss')
plt.legend()
plt.savefig(os.path.join(save_dir, 'loss.png'))

plt.figure()
plt.plot(list(range(1, epochs + 1)), train_acc_list, c='b', label='train_acc')
plt.plot(list(range(1, epochs + 1)), val_acc_list, c='y', label='val_acc')
plt.xlabel('epoch')
plt.ylabel('accuracy')
plt.legend()
plt.savefig(os.path.join(save_dir, 'acc.png'))

plt.figure()
plt.plot(list(range(1, epochs + 1)), train_auc_list, c='b', label='train_auc')
plt.plot(list(range(1, epochs + 1)), val_auc_list, c='y', label='val_auc')
plt.xlabel('epoch')
plt.ylabel('auc')
plt.legend()
plt.savefig(os.path.join(save_dir, 'auc.png'))

plt.figure()
plt.plot(list(range(1, epochs + 1)), train_f1_list, c='b', label='train_f1')
plt.plot(list(range(1, epochs + 1)), val_f1_list, c='y', label='val_f1')
plt.xlabel('epoch')
plt.ylabel('f1')
plt.legend()
plt.savefig(os.path.join(save_dir, 'f1.png'))

plt.figure()
plt.plot(list(range(1, epochs + 1)), train_mcc_list, c='b', label='train_mcc')
plt.plot(list(range(1, epochs + 1)), val_mcc_list, c='y', label='val_mcc')
plt.xlabel('epoch')
plt.ylabel('mcc')
plt.legend()
plt.savefig(os.path.join(save_dir, 'mcc.png'))

plt.figure()
plt.plot(list(range(1, epochs + 1)), train_iou_list, c='b', label='train_iou')
plt.plot(list(range(1, epochs + 1)), val_iou_list, c='y', label='val_iou')
plt.xlabel('epoch')
plt.ylabel('iou')
plt.legend()
plt.savefig(os.path.join(save_dir, 'iou.png'))

