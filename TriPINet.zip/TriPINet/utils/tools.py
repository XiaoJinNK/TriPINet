import numpy as np
import os
import pickle
from utils.Dataloader import TemperDataset
import torch
from torch.utils.data import DataLoader
from config import Dataset_Path
from torch import nn


def read_txt(txt, data_num=None):
    """
    Get lines in .txt file.
    txt: .txt file path
    data_num: The value of one dataset in parameter data_num_list. If None, all txt lines will be used. If Int, the
              first data_num lines will be used.
    """
    with open(txt, 'r') as f:
        if data_num is not None:
            data = f.read().splitlines()[:data_num]
        else:
            data = f.read().splitlines()
    return data


def split_dataset(data_lines, mask_lines, p_train=0.8, p_val=0.2, data_nums=None, save_split_path=None):
    """
    Split dataset. If p_train + p_val == 1, the third return will be (array([]), array([])).
    :param data_lines: List, each element is a img path
    :param mask_lines: List, each element is a mask path
    :param p_train: split train data percent
    :param p_val: split val data percent
    :param data_nums: List, (train, val, test) nums tuple
    :param save_split_path: save the split result, the txts will be saved at save_split_path
    :return: (train_data_lines, train_mask_lines), (val_data_lines, val_mask_lines), (test_data_lines, test_mask_lines)
    """
    assert 0.0 <= p_train + p_val <= 1.0, f'split percent error: train: {p_train}  val: {p_val}'

    '''划分数据集'''
    if data_nums is not None:
        train_num, val_num, test_num = data_nums
        data_num = np.sum(data_nums)
    else:
        data_num = len(data_lines)
        train_num = int(data_num * p_train)
        if p_train + p_val == 1.0:
            val_num = data_num - train_num
        else:
            val_num = int(data_num * p_val)
        test_num = data_num - train_num - val_num
    print('data_num:', data_num, ' train_num:', train_num, ' val_num:', val_num, ' test_num:', test_num)

    # 随机生成序列
    data_index = np.random.permutation(data_num)
    # 在随机序列中随机选择
    train_index = np.random.choice(data_index, size=train_num, replace=False)
    valtest_index = np.setdiff1d(data_index, train_index)
    val_index = np.random.choice(valtest_index, size=val_num, replace=False)
    test_index = np.random.choice(np.setdiff1d(valtest_index, val_index), size=test_num, replace=False)

    train_data_lines = np.array(data_lines)[train_index]
    train_mask_lines = np.array(mask_lines)[train_index]

    val_data_lines = np.array(data_lines)[val_index]
    val_mask_lines = np.array(mask_lines)[val_index]

    test_data_lines = np.array(data_lines)[test_index]
    test_mask_lines = np.array(mask_lines)[test_index]

    assert len(np.unique(train_index)) == len(train_index) == train_num
    assert len(np.unique(val_index) == len(val_index)) == val_num
    assert len(np.unique(test_index) == len(test_index)) == (data_num - train_num - val_num)

    if save_split_path is not None:
        lines = [train_data_lines, train_mask_lines, val_data_lines, val_mask_lines, test_data_lines, test_mask_lines]
        txts = ['train_img', 'train_mask', 'val_img', 'val_mask', 'test_img', 'test_mask']
        for i, txt in enumerate(txts):
            with open(os.path.join(save_split_path, txt + '.txt'), 'w') as f:
                for line in lines[i]:
                    f.write(line + '\n')

    return (train_data_lines, train_mask_lines), \
           (val_data_lines, val_mask_lines), \
           (test_data_lines, test_mask_lines)


def generate_trainval_dataloaders(data_txt_list, mask_txt_list, batch_size, save_dir,
                    p_train=0.8,
                    p_val=0.1,
                    data_num_list=None,
                    img_transform_list=None,
                    mask_transform_list=None,
                    data_aug=False,
                    num_workers=0):
    """
    划分并生成训练、验证、测试集，并把测试集保存在 save_dir 中的 test_data.pkl 中
    :param data_txt_list: 数据集的篡改图片txt的列表，例如 [CASIAv1_SP_txt, CASIAv1_CM_txt]
    :param mask_txt_list: 数据集的 mask 的txt的列表，例如 [CASIAv1_SP_MASK_txt, CASIAv1_CM_MASK_txt]
    :param save_dir: 训练结果的保存文件夹路径
    :param batch_size: 训练的 batch_size
    :param img_transform_list: 训练图像的预处理 torchvision 操作列表，例如 [transforms.Resize((img_h, img_w))]
    :param mask_transform_list: mask 的预处理 torchvision 操作列表，例如 [transforms.Resize((img_h, img_w))]
    :param num_workers: torch.utils.data.DataLoader 的 num_workers 参数
    :return: (train_datald, eval_datald)
    """
    data_lines = []
    for i, data_txt in enumerate(data_txt_list):
        if data_num_list is not None:
            data = read_txt(data_txt, data_num=data_num_list[i])
        else:
            data = read_txt(data_txt, data_num=None)
        data_lines.extend(data)
    mask_lines = []
    for i, mask_txt in enumerate(mask_txt_list):
        if data_num_list is not None:
            data = read_txt(mask_txt, data_num=data_num_list[i])
        else:
            data = read_txt(mask_txt, data_num=None)
        mask_lines.extend(data)

    train_data, val_data, test_data = split_dataset(data_lines, mask_lines, p_train=p_train, p_val=p_val)
    train_data_lines, train_mask_lines = train_data
    val_data_lines, val_mask_lines = val_data

    with open(os.path.join(save_dir, 'test_data.pkl'), 'wb') as f:
        pickle.dump(test_data, f)

    train_dataset = TemperDataset(train_data_lines, train_mask_lines,
                                  img_transform_list=img_transform_list,
                                  mask_transform_list=mask_transform_list,
                                  dataAug=data_aug)
    # train_datald = DataLoader(train_dataset, batch_size=batch_size, shuffle=True, num_workers=num_workers,
    #                           pin_memory=True)
    train_datald = DataLoader(train_dataset, batch_size=batch_size, shuffle=True, num_workers=num_workers,
                              pin_memory=True)

    eval_dataset = TemperDataset(val_data_lines, val_mask_lines,
                                 img_transform_list=img_transform_list,
                                 mask_transform_list=mask_transform_list,
                                 dataAug=False)
    # eval_datald = DataLoader(eval_dataset, batch_size=batch_size, shuffle=False, num_workers=num_workers,
    #                          pin_memory=True)
    eval_datald = DataLoader(eval_dataset, batch_size=batch_size, shuffle=False, num_workers=num_workers,
                             pin_memory=True)

    return train_datald, eval_datald


def get_dataloader(data_txt, mask_txt, batch_size, img_transform_list=None, mask_transform_list=None, shuffle=True, data_aug=False, num_workers=0):
    train_data_lines = read_txt(data_txt, data_num=None)
    train_mask_lines = read_txt(mask_txt, data_num=None)

    dataset = TemperDataset(train_data_lines, train_mask_lines, img_transform_list=img_transform_list, mask_transform_list=mask_transform_list, dataAug=data_aug)
    dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=shuffle, num_workers=num_workers, pin_memory=True)
    return dataloader


# def get_finetune_dataloaders(dataset, batch_size, img_transform_list=None, mask_transform_list=None, num_workers=0):
#     """
#     :param save_dir: 训练结果的保存文件夹路径
#     :param batch_size: 训练的 batch_size
#     :param img_transform_list: 训练图像的预处理 torchvision 操作列表，例如 [transforms.Resize((img_h, img_w))]
#     :param mask_transform_list: mask 的预处理 torchvision 操作列表，例如 [transforms.Resize((img_h, img_w))]
#     :param num_workers: torch.utils.data_protocol.DataLoader 的 num_workers 参数
#     :return: (train_datald, eval_datald)
#     """
#     dp = Dataset_Path()
#
#     if dataset == 'NIST16':
#         train_img_txt = dp.NIST16_train_img_txt
#         train_mask_txt = dp.NIST16_train_mask_txt
#         test_img_txt = dp.NIST16_test_img_txt
#         test_mask_txt = dp.NIST16_test_mask_txt
#     else:
#         print('wrong dataset', dataset)
#         return
#
#     with open(train_img_txt, 'r') as f:
#         train_img_lines = f.read().splitlines()
#     with open(train_mask_txt, 'r') as f:
#         train_mask_lines = f.read().splitlines()
#     with open(test_img_txt, 'r') as f:
#         test_img_lines = f.read().splitlines()
#     with open(test_mask_txt, 'r') as f:
#         test_mask_lines = f.read().splitlines()
#
#     train_dataset = TemperDataset(train_img_lines, train_mask_lines,
#                                   img_transform_list=img_transform_list,
#                                   mask_transform_list=mask_transform_list,
#                                   dataAug=True)
#     train_datald = DataLoader(train_dataset, batch_size=batch_size, shuffle=True, num_workers=num_workers,
#                               pin_memory=True)
#     test_dataset = TemperDataset(test_img_lines, test_mask_lines,
#                                  img_transform_list=img_transform_list,
#                                  mask_transform_list=mask_transform_list,
#                                  dataAug=False)
#     test_datald = DataLoader(test_dataset, batch_size=batch_size, shuffle=False, num_workers=num_workers,
#                              pin_memory=True)
#
#     return train_datald, test_datald
#
#
# def get_protocol_dataloaders(batch_size, img_transform_list=None, mask_transform_list=None, num_workers=0):
#     """
#     :param save_dir: 训练结果的保存文件夹路径
#     :param batch_size: 训练的 batch_size
#     :param img_transform_list: 训练图像的预处理 torchvision 操作列表，例如 [transforms.Resize((img_h, img_w))]
#     :param mask_transform_list: mask 的预处理 torchvision 操作列表，例如 [transforms.Resize((img_h, img_w))]
#     :param num_workers: torch.utils.data_protocol.DataLoader 的 num_workers 参数
#     :return: (train_datald, eval_datald)
#     """
#     dp = Dataset_Path()
#     train_img_lines = []
#     for data_txt in dp.fine_tune_img:
#         with open(data_txt, 'r') as f:
#             data = f.read().splitlines()
#         train_img_lines.extend(data)
#     train_mask_lines = []
#     for data_txt in dp.fine_tune_mask:
#         with open(data_txt, 'r') as f:
#             data = f.read().splitlines()
#         train_mask_lines.extend(data)
#
#     test_img_lines = []
#     for data_txt in dp.test_img:
#         with open(data_txt, 'r') as f:
#             data = f.read().splitlines()
#         test_img_lines.extend(data)
#     test_mask_lines = []
#     for data_txt in dp.test_mask:
#         with open(data_txt, 'r') as f:
#             data = f.read().splitlines()
#         test_mask_lines.extend(data)
#
#     train_dataset = TemperDataset(train_img_lines, train_mask_lines,
#                                   img_transform_list=img_transform_list,
#                                   mask_transform_list=mask_transform_list,
#                                   dataAug=True)
#     train_datald = DataLoader(train_dataset, batch_size=batch_size, shuffle=True, num_workers=num_workers,
#                               pin_memory=True)
#     test_dataset = TemperDataset(test_img_lines, test_mask_lines,
#                                  img_transform_list=img_transform_list,
#                                  mask_transform_list=mask_transform_list,
#                                  dataAug=False)
#     test_datald = DataLoader(test_dataset, batch_size=batch_size, shuffle=False, num_workers=num_workers,
#                              pin_memory=True)
#
#     return train_datald, test_datald


def get_preds_prob_map(logits_mask):
    """
    :param logits_mask: 网络最后一个卷积层的输出结果 (B, C, H, W)
    :return: tampering localization probability map（像素被篡改的概率图）
    """
    return torch.sigmoid(logits_mask)


def get_preds_mask(logits_mask, threshold=0.5):
    """
    :param logits_mask: 网络最后一个卷积层的输出结果 (B, C, H, W)
    :param threshold: 二值化的阈值 要二值化的值在[0, 1]之间
    :return: 二值化的 tampering localization probability map
    """
    assert 0 <= threshold <= 1
    preds_mask_map = get_preds_prob_map(logits_mask)
    return (preds_mask_map >= threshold).type(torch.IntTensor)


def binarize_mask(mask, threshold=128):
    mask[torch.where(mask < threshold)] = 0
    mask[torch.where(mask >= threshold)] = 1
    return mask


class Sobel(nn.Module):
    def __init__(self):
        super(Sobel, self).__init__()
        self.sobel_conv_x, self.sobel_conv_y = self.get_sobel()

    def get_sobel(self):
        filter_x = torch.tensor([
            [1, 0, -1],
            [2, 0, -2],
            [1, 0, -1],
        ]).to(torch.float32)
        filter_y = torch.tensor([
            [1, 2, 1],
            [0, 0, 0],
            [-1, -2, -1],
        ]).to(torch.float32)
        filter_x = filter_x.reshape((1, 1, 3, 3))
        filter_y = filter_y.reshape((1, 1, 3, 3))
        filter_x = nn.Parameter(filter_x, requires_grad=False)
        filter_y = nn.Parameter(filter_y, requires_grad=False)
        conv_x = nn.Conv2d(1, 1, kernel_size=3, stride=1, padding=1, bias=False)
        conv_x.weight = filter_x
        conv_y = nn.Conv2d(1, 1, kernel_size=3, stride=1, padding=1, bias=False)
        conv_y.weight = filter_y
        sobel_x = nn.Sequential(conv_x, nn.BatchNorm2d(1))
        sobel_y = nn.Sequential(conv_y, nn.BatchNorm2d(1))
        return sobel_x, sobel_y

    def forward(self, x):
        if len(x.shape) != 4:
            x = x.reshape(1, 1, x.shape[0], x.shape[1])
        x = x.to(torch.float32)
        g_x = self.sobel_conv_x(x)
        g_y = self.sobel_conv_y(x)
        g = torch.sqrt(torch.pow(g_x, 2) + torch.pow(g_y, 2))
        return torch.sigmoid(g) * x


if __name__ == '__main__':
    img_path = r'D:\Datasets\Forensics-Dataset\CASIA_v2.0\CASIA2.0_Groundtruth\Tp_D_NRN_M_B_nat00041_arc00065_11444_gt.png'
    import cv2
    import matplotlib.pyplot as plt
    import torch.nn.functional as F
    img = torch.tensor(cv2.imread(img_path, flags=cv2.IMREAD_GRAYSCALE))
    img = img.reshape(1, 1, img.shape[0], img.shape[1])
    print(img.shape)
    img = binarize_mask(F.interpolate(img.to(torch.float32), scale_factor=1 / 2, mode='bilinear'))
    print(img.shape)
    # img = Sobel()(torch.tensor(img)).detach().numpy()
    # print(img.shape)
    # img = img.squeeze(0).squeeze(0)

    # print(img.shape)
    # img = np.squeeze(img, 2)
    # # img = np.transpose(img, a   xes=(1, 2, 0))
    plt.imshow(img, cmap='gray')
    plt.show()