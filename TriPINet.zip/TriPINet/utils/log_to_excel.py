import os
import time
import pandas as pd
from config import Config
from evaluation.test import dir_3


file = r'D:\BaiduNetdiskWorkspace\paper\data-1.xlsx'

'''
['Done', '修改', '数据', '数据增强', 'skip_connection', 'low_level_feature_fusion', 'loss', 'epoch', 'lr', 'batch_size', 'weight_decay', 
 'lr_schedule', 'test_threshold', '时间设备', 'name', '同分布测试集（auc/f1）', 'CASIAv1-SP', 'CASIAv1-CM', 'COVER', 'COLUMB']
'''


df = pd.read_excel(file)
row, col = df.shape

CONFIG = Config()

with open(os.path.join(CONFIG.save_dir, 'terminal.log'), 'r') as f:
    epoch = f.readlines()[-4].split(' ')[-1].strip() + '/' + str(CONFIG.epochs)

time_str = str(time.strftime("%Y-%m-%d", time.localtime())) + '-3080'

with open(os.path.join(CONFIG.save_dir, dir_3, 'test_result.txt'), 'r') as f:
    data = f.readlines()
    test = data[:6]
    v1_SP = data[7: 13]
    v1_CM = data[14: 20]
    COVER = data[21: 27]
    COLUMB = data[28: 34]


round_num = 4
new_row_dict = {
    'Done': '√',
    '修改': 'Decoder_add, skip, llff_w_bn',
    '数据': 'CASIAv2 SP + CM resize 256',
    '数据增强': '×',
    'skip_connection': f'{CONFIG.skip_connection}',
    'low_level_feature_fusion': f'{CONFIG.low_level_feature_fusion}',
    'loss': f'torch.nn.BCEWithLogitsLoss',
    'pos_weight': f'{CONFIG.pos_weight.item()}',
    'epoch': epoch,
    'lr': CONFIG.learning_rate,
    'batch_size': CONFIG.batch_size,
    'weight_decay': CONFIG.weight_decay,
    'lr_schedule': f'steplr {CONFIG.gamma}/{CONFIG.step_size} epochs',
    'test_threshold': CONFIG.test_threshold,
    '时间设备': CONFIG.dir_name.split('#')[0],
    'name': CONFIG.dir_name,
    '同分布测试集（auc/f1）': str(round(float(test[1].split(' ')[-1].strip()), round_num)) + '/' + str(round(float(test[2].split(' ')[-1].strip()), round_num)),
    'CASIAv1-SP': str(round(float(v1_SP[1].split(' ')[-1].strip()), round_num)) + '/' + str(round(float(v1_SP[2].split(' ')[-1].strip()), round_num)),
    'CASIAv1-CM': str(round(float(v1_CM[1].split(' ')[-1].strip()), round_num)) + '/' + str(round(float(v1_CM[2].split(' ')[-1].strip()), round_num)),
    'COVER': str(round(float(COVER[1].split(' ')[-1].strip()), round_num)) + '/' + str(round(float(COVER[2].split(' ')[-1].strip()), round_num)),
    'COLUMB': str(round(float(COLUMB[1].split(' ')[-1].strip()), round_num)) + '/' + str(round(float(COLUMB[2].split(' ')[-1].strip()), round_num))
}


df = df.append(pd.DataFrame([new_row_dict]), ignore_index=True)

df.to_excel(file)