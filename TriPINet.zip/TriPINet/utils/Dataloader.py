import os

import matplotlib.pyplot as plt
from PIL import Image
import cv2
import numpy as np
import torch
import torchvision
import torchvision.transforms as transforms
from torch.utils.data.dataset import Dataset
from collections import Counter
from utils import tools
from config import Config
from utils.data_augmentation import random_horizontal_flip, random_vertical_flip, colorEnhance


class TemperDataset(Dataset):
    """
    图片名称和对应的mask名称必须相同。

    返回nadarray类型的元组(img, mask)
    """

    def __init__(self, data_lines, mask_lines, img_transform_list=None, mask_transform_list=None, dataAug=False):
        super(TemperDataset, self).__init__()
        # 图片文件夹
        self.data_lines = data_lines
        # mask文件夹
        self.mask_lines = mask_lines
        # 图片数量
        self.data_num = len(self.data_lines)
        # 数据预处理
        self.img_transform_list = img_transform_list
        self.mask_transform_list = mask_transform_list
        self.dataAug = dataAug

    def __len__(self):
        return self.data_num

    def __getitem__(self, index):
        # cv2 imread -> PIL.Image
        # print(self.data_lines[index].strip())
        img = cv2.imread(self.data_lines[index].strip(), flags=cv2.IMREAD_COLOR)  # BGR
        img = cv2.cvtColor(img, code=cv2.COLOR_BGR2RGB)  # RGB
        img = Image.fromarray(img).convert('RGB')

        mask = cv2.imread(self.mask_lines[index].strip(), flags=cv2.IMREAD_GRAYSCALE)
        mask = Image.fromarray(mask).convert('L')

        # data augmentation
        if self.dataAug:
            # 随机翻转
            img, mask = random_horizontal_flip([img, mask])
            img, mask = random_vertical_flip([img, mask])































            # 颜色增强
            # img = colorEnhance(img)

        # Resize and ToTensor
        if self.img_transform_list is not None:
            img = transforms.Compose(self.img_transform_list)(img)
        img = transforms.ToTensor()(img)

        if self.mask_transform_list is not None:
            mask = transforms.Compose(self.mask_transform_list)(mask)
        mask = transforms.PILToTensor()(mask)
        tools.binarize_mask(mask, threshold=128)
        # img:  (C, H, W)
        # mask: (C, H, W)
        return img.to(torch.float32), mask.to(torch.uint8)

    def summary_img_size(self):
        w_list = []
        h_list = []
        for line in self.data_lines:
            img = cv2.imread(line[:-1])
            h, w, _ = img.shape
            w_list.append(w)
            h_list.append(h)

        return Counter(h_list), Counter(w_list)


if __name__ == '__main__':

    # CASIAv1_SP_txt = '../data/CASIA_v1/SP_img.txt'
    # CASIAv1_SP_MASK_txt = '../data/CASIA_v1/SP_mask.txt'
    # CASIAv1_CM_txt = '../data/CASIA_v1/CM_img.txt'
    # CASIAv1_CM_MASK_txt = '../data/CASIA_v1/CM_mask.txt'
    # CASIAv2_img_txt = '../data/CASIA_v2/img.txt'
    # CASIAv2_mask_txt = '../data/CASIA_v2/mask.txt'
    # croped_NIST_txt = '../data/Croped_data/NIST2016/img.txt'
    # croped_NIST_mask_txt = '../data/Croped_data/NIST2016/mask.txt'
    # COLUMBIA_img_txt = '../data/COLUMB/img.txt'
    # COLUMBIA_mask_txt = '../data/COLUMB/mask.txt'
    COVERAGE_img_txt = '../data/COVERAGE/img.txt'
    COVERAGE_mask_txt = '../data/COVERAGE/mask.txt'

    # data_txt_list = [CASIAv1_SP_txt, CASIAv1_CM_txt]
    # mask_txt_list = [CASIAv1_SP_MASK_txt, CASIAv1_CM_MASK_txt]
    # data_txt_list = [CASIAv2_img_txt]
    # mask_txt_list = [CASIAv2_mask_txt]
    # data_txt_list = [croped_NIST_txt]
    # mask_txt_list = [croped_NIST_mask_txt]
    # data_txt_list = [COLUMBIA_img_txt]
    # mask_txt_list = [COLUMBIA_mask_txt]
    CONFIG = Config()
    data_txt_list = [CONFIG.CASIAv2_SP_img_txt, CONFIG.CASIAv2_CM_img_txt]
    mask_txt_list = [CONFIG.CASIAv2_SP_mask_txt, CONFIG.CASIAv2_CM_mask_txt]

    train_data, val_data, _ = tools.split_dataset(data_txt_list, mask_txt_list, p_train=0.8, p_val=0.2,
                                                  data_num_list=CONFIG.data_num_list)
    train_data_lines, train_mask_lines = train_data
    val_data_lines, val_mask_lines = val_data

    print(len(train_data_lines), ' ', len(val_data_lines), ' ', len(_[0]))
    dataset = TemperDataset(train_data_lines, train_mask_lines,
                            img_transform_list=CONFIG.img_transform_list,
                            mask_transform_list=CONFIG.mask_transform_list)
    train_datald = torch.utils.data.DataLoader(dataset, batch_size=4, shuffle=True, num_workers=0,
                                               pin_memory=True)
    # h_stat, w_stat = dataset.summury_img_size()
    # # h_stat = sorted(h_stat.items(), key=lambda dic: (dic[1], dic[0]))
    # print('h_stat', h_stat)
    # print('w_stat', w_stat)
    #
    # plt.bar(h_stat.keys(), height=h_stat.values(), width=0.5)
    # plt.show()

    for img, mask in train_datald:
        # print('------------------------------')
        # print(img.shape, img.dtype)
        # print(mask.shape, mask.dtype)
        #
        # plt.figure()
        # plt.subplot(1, 2, 1)
        # plt.imshow(img.movedim(0, 2).numpy())
        # plt.subplot(1, 2, 2)
        # plt.imshow(mask.movedim(0, 2).numpy(), cmap='gray')
        # plt.show()
        print(img.shape)
        print(mask.shape)
