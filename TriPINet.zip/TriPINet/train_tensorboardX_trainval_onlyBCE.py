import os
import logging
import matplotlib.pyplot as plt
import shutil

import numpy as np
from tqdm import tqdm
import pickle
from utils.metrics import *
from utils.tools import get_dataloader
from config import Config
from tensorboardX import SummaryWriter
import time
import random
from utils.loss import HybridLossWithLogits

'''
Initialize Comet
'''


# Initialize the SummaryWriter
# Create an experiment with your api key
# experiment = Experiment(
#     api_key="EPN9ru5evgX8AtQFF5EizB7S9",
#     project_name="MVSS",
#     workspace="crrcoo",
# )


def train(epoch, verbose=True):
    global model, train_datald, optimizer
    global train_auc_list, train_f1_list, train_mcc_list, train_iou_list, train_acc_list, train_p_list, train_r_list, train_ap_list
    '''training'''
    model.train()
    train_loss, auc_list, f1_list, mcc_list, iou_list, acc_list, p_list, r_list, ap_list = 0.0, [], [], [], [], [], [], [], []
    num_batchs = len(train_datald)
    for i, (img, mask) in enumerate(tqdm(train_datald)):
        # plt.figure()
        # for i in range(8):
        #     plt.subplot(2, 4, i+1)
        #     plt.imshow(img[i].squeeze(0).movedim(0, 2))
        # plt.figure()
        # for i in range(8):
        #     plt.subplot(2, 4, i+1)
        #     plt.imshow(mask[i].squeeze(0), cmap='gray')
        # plt.show()
        # recover the learning rate after warmup
        img = img.to(cfg.device)
        mask = mask.to(cfg.device)

        fusion, out1, out2, out3, out4, logits = model(img)

        optimizer.zero_grad()
        loss0 = cfg.criterion_pixel(fusion.float(), mask.float())
        loss1 = cfg.criterion_pixel(out1.float(), mask.float())
        loss2 = cfg.criterion_pixel(out2.float(), mask.float())
        loss3 = cfg.criterion_pixel(out3.float(), mask.float())
        loss4 = cfg.criterion_pixel(out4.float(), mask.float())
        loss5 = cfg.criterion_pixel(logits.float(), mask.float())
        loss = loss0 + loss1 + loss2 + loss3 + loss4 + loss5
        loss.backward()
        optimizer.step()
        train_loss += loss.item()

        with torch.no_grad():
            logits = logits.detach().cpu()
            mask = mask.cpu()
            auc, f1, mcc, iou, acc, p, r, ap, _ = get_metrics(logits, mask, threshold=cfg.train_threshold)
            auc_list.extend(auc)
            f1_list.extend(f1)
            mcc_list.extend(mcc)
            iou_list.extend(iou)
            acc_list.extend(acc)
            p_list.extend(p)
            r_list.extend(r)
            ap_list.extend(ap)

    train_loss = train_loss / len(train_datald)
    train_loss_list.append(train_loss)
    train_auc_list.append(np.mean(auc_list))
    train_f1_list.append(np.mean(f1_list))
    train_mcc_list.append(np.mean(mcc_list))
    train_iou_list.append(np.mean(iou_list))
    train_acc_list.append(np.mean(acc_list))
    train_p_list.append(np.mean(p_list))
    train_r_list.append(np.mean(r_list))
    train_ap_list.append(np.mean(ap_list))

    writer = SummaryWriter(tbX_train_loss)
    writer.add_scalar('Loss', train_loss, epoch)
    writer.close()
    writer = SummaryWriter(tbX_train_f1)
    writer.add_scalar('F1', np.mean(f1_list), epoch)
    writer.close()

    if verbose:
        logging.info(f'auc: {train_auc_list[-1]}')
        logging.info(f'ap: {train_ap_list[-1]}')
        logging.info(f'f1: {train_f1_list[-1]}')
        logging.info(f'mcc: {train_mcc_list[-1]}')
        logging.info(f'iou: {train_iou_list[-1]}')
        logging.info(f'acc: {train_acc_list[-1]}')
        logging.info(f'p: {train_p_list[-1]}')
        logging.info(f'r: {train_r_list[-1]}')


def validation(epoch, verbose=True):
    global model, eval_datald
    global val_auc_list, val_f1_list, val_mcc_list, val_iou_list, val_acc_list, val_p_list, val_r_list, val_ap_list

    model.eval()
    eval_loss, auc_list, f1_list, mcc_list, iou_list, acc_list, p_list, r_list, ap_list = 0.0, [], [], [], [], [], [], [], []
    with torch.no_grad():
        for img, mask in tqdm(eval_datald):
            img = img.to(cfg.device)
            mask = mask.to(cfg.device)

            fusion, out1, out2, out3, out4, logits = model(img)

            loss0 = cfg.criterion_pixel(fusion.float(), mask.float())
            loss1 = cfg.criterion_pixel(out1.float(), mask.float())
            loss2 = cfg.criterion_pixel(out2.float(), mask.float())
            loss3 = cfg.criterion_pixel(out3.float(), mask.float())
            loss4 = cfg.criterion_pixel(out4.float(), mask.float())
            loss5 = cfg.criterion_pixel(logits.float(), mask.float())
            loss = loss0 + loss1 + loss2 + loss3 + loss4 + loss5

            eval_loss += loss.item()

            logits = logits.detach().cpu()
            mask = mask.cpu()
            auc, f1, mcc, iou, acc, p, r, ap, _ = get_metrics(logits, mask, threshold=cfg.train_threshold)
            auc_list.extend(auc)
            f1_list.extend(f1)
            mcc_list.extend(mcc)
            iou_list.extend(iou)
            acc_list.extend(acc)
            p_list.extend(p)
            r_list.extend(r)
            ap_list.extend(ap)

        val_loss = eval_loss / len(eval_datald)
        val_loss_list.append(val_loss)

        # 如果val_loss固定步长下不下降，学习率降低为原来的0.5倍
        global Count  # 声明Count为全局变量，才可以修改函数外的全局变量的值
        if len(val_loss_list) > cfg.auto_lr_down_step and \
                val_loss_list[-1 * cfg.auto_lr_down_step - 1] <= min(val_loss_list[-1 * cfg.auto_lr_down_step:]) \
                and Count >= cfg.auto_lr_down_step:
        # if len(val_loss_list) > cfg.auto_lr_down_step and \
        #         val_loss_list[-1 * cfg.auto_lr_down_step - 1] <= min(val_loss_list[-1 * cfg.auto_lr_down_step:]):
            Count = 0
            cfg.learning_rate *= cfg.auto_lr_down_rate
            for params in optimizer.param_groups:
                # 遍历Optimizer中的每一组参数，将该组参数的学习率 * 0.5
                params['lr'] = cfg.learning_rate

        val_auc_list.append(np.mean(auc_list))
        val_ap_list.append(np.mean(ap_list))
        val_f1_list.append(np.mean(f1_list))
        val_mcc_list.append(np.mean(mcc_list))
        val_iou_list.append(np.mean(iou_list))
        val_acc_list.append(np.mean(acc_list))
        val_p_list.append(np.mean(p_list))
        val_r_list.append(np.mean(r_list))

        # experiment.log_metric('val_loss', val_loss, step=epoch)
        # experiment.log_metric('val_mcc', mcc, step=epoch)
        # experiment.log_metric('val_f1', f1, step=epoch)
        # experiment.log_metric('val_acc', acc, step=epoch)

        writer = SummaryWriter(tbX_val_loss)
        writer.add_scalar('Loss', val_loss, epoch)
        writer.close()
        writer = SummaryWriter(tbX_val_f1)
        writer.add_scalar('F1', np.mean(f1_list), epoch)
        writer.close()

        if verbose:
            logging.info(f'auc: {val_auc_list[-1]}')
            logging.info(f'ap: {val_ap_list[-1]}')
            logging.info(f'f1: {val_f1_list[-1]}')
            logging.info(f'mcc: {val_mcc_list[-1]}')
            logging.info(f'iou: {val_iou_list[-1]}')
            logging.info(f'acc: {val_acc_list[-1]}')
            logging.info(f'p: {val_p_list[-1]}')
            logging.info(f'r: {val_r_list[-1]}')


if __name__ == '__main__':
    '''取消随机性'''
    # seed = 123
    # random.seed(seed)
    # np.random.seed(seed)
    # torch.manual_seed(seed)  # 为CPU设置种子用于生成随机数，以使得结果是确定的   　　
    # torch.cuda.manual_seed(seed)  # 为当前GPU设置随机种子；
    # # 该将 CuDNN 设置为确定性模式(主要影响卷积)
    # torch.backends.cudnn.deterministic = True
    # torch.backends.cudnn.benchmark = False

    '''program configuration'''
    cfg = Config()
    save_dir = cfg.save_dir

    '''保存重要源代码'''
    os.makedirs(os.path.join(save_dir, 'pth'), exist_ok=True)
    if os.path.exists(os.path.join(save_dir, 'scripts')):
        shutil.rmtree(os.path.join(save_dir, 'scripts'))
    shutil.copytree('.', dst=os.path.join(save_dir, 'scripts'))


    '''initialize logging'''
    with open(os.path.join(save_dir, 'terminal.log'), 'w'):
        pass
    log_format = '%(asctime)s %(message)s'
    logging.basicConfig(stream=sys.stdout, level=logging.INFO,
                        format=log_format, datefmt='%m/%d %I:%M:%S %p')
    fh = logging.FileHandler(os.path.join(save_dir, 'terminal.log'))
    fh.setFormatter(logging.Formatter(log_format))
    logging.getLogger().addHandler(fh)

    logging.info(f'Saving directory: {save_dir}')

    # 新建记录 loss 的 txt
    LOG_TXT = os.path.join(save_dir, 'log_loss.log')
    with open(LOG_TXT, 'w'):
        pass

    '''tensorboardX configuration'''
    if cfg.time_str is None:
        time_str = time.strftime("%Y-%m-%d_%H-%M-%S", time.localtime())
    else:
        time_str = cfg.time_str
    logging.info(f'tensorboardX time: {time_str}')
    tbX_train_loss = './tensorboardX/' + time_str + '/train_loss'
    tbX_val_loss = './tensorboardX/' + time_str + '/val_loss'
    tbX_train_f1 = './tensorboardX/' + time_str + '/train_f1'
    tbX_val_f1 = './tensorboardX/' + time_str + '/val_f1'

    '''load data'''
    train_datald = get_dataloader(cfg.train_img_txt_list, cfg.train_mask_txt_list, batch_size=cfg.batch_size,
                                  shuffle=True,
                                  img_transform_list=cfg.img_transform_list,
                                  mask_transform_list=cfg.mask_transform_list,
                                  data_aug=cfg.data_aug,
                                  num_workers=cfg.num_workers)
    eval_datald = get_dataloader(cfg.val_img_txt_list, cfg.val_mask_txt_list, batch_size=cfg.batch_size,
                                  shuffle=False,
                                  img_transform_list=cfg.img_transform_list,
                                  mask_transform_list=cfg.mask_transform_list,
                                  data_aug=False,
                                  num_workers=cfg.num_workers)

    '''training device and model'''
    model = cfg.model.to(cfg.device)

    if cfg.model_pth is not None:
        logging.info(f'loading trained model pth: {cfg.model_pth}')
        model.load_state_dict(torch.load(cfg.model_pth))

    optimizer = cfg.optimizer(model.parameters(), lr=cfg.learning_rate, weight_decay=cfg.weight_decay)

    Count = 0  # 计数当前学习率已经训练的epoch数
    train_loss_list, train_auc_list, train_f1_list, train_mcc_list, train_iou_list, train_acc_list, train_p_list, train_r_list, train_ap_list = [], [], [], [], [], [], [], [], []
    val_loss_list, val_auc_list, val_f1_list, val_mcc_list, val_iou_list, val_acc_list, val_p_list, val_r_list, val_ap_list = [], [], [], [], [], [], [], [], []

    for epoch in range(cfg.start_epoch, cfg.epochs + 1):
        logging.info('===========================================================================================')

        lr = 0.0
        # 使用lr获取优化器的学习率
        for params in optimizer.param_groups:
            # Optimizer中每一组参数学习率 are the same
            lr = params['lr']
            break

        logging.info(f'epoch {epoch}  learning rate: {lr}')
        '''training'''
        logging.info('-----------train-------------------------')
        train(epoch=epoch)

        torch.save(model.state_dict(), os.path.join(save_dir, 'pth', f'epoch_{str(epoch)}.pth'))
        Count += 1

        '''evaluation'''
        logging.info('-----------val-------------------------')
        validation(epoch=epoch)
        logging.info('---------------------------------------')
        logging.info(f'epoch {epoch}  train loss: {train_loss_list[-1]}  eval loss: {val_loss_list[-1]}')

        # 记录 loss 到 txt
        with open(LOG_TXT, 'a') as f:
            f.write(f'epoch {epoch}  train loss: {train_loss_list[-1]}  eval loss: {val_loss_list[-1]}\n')

    '''关闭Comet'''
    # experiment.end()

    # 存储每个 epoch 的 metircs list 到 save_dir 的 result_metrics.pkl 中
    with open(os.path.join(save_dir, 'result_metrics.pkl'), 'wb') as f:
        pickle.dump((train_loss_list, val_loss_list,
                     train_auc_list, train_f1_list, train_mcc_list, train_iou_list, train_acc_list, train_p_list, train_r_list, train_ap_list,
                     val_auc_list, val_f1_list, val_mcc_list, val_iou_list, val_acc_list, val_p_list, val_r_list, val_ap_list), f)


    logging.info(f'max val auc = {np.max(val_auc_list)}  epoch {np.argmax(val_auc_list) + cfg.start_epoch}')
    logging.info(f'max val f1 = {np.max(val_f1_list)}  epoch {np.argmax(val_f1_list) + cfg.start_epoch}')
    logging.info(f'max val mcc = {np.max(val_mcc_list)}  epoch {np.argmax(val_mcc_list) + cfg.start_epoch}')
    logging.info(f'max val iou = {np.max(val_iou_list)}  epoch {np.argmax(val_iou_list) + cfg.start_epoch}')
    logging.info(f'max val acc = {np.max(val_acc_list)}  epoch {np.argmax(val_acc_list) + cfg.start_epoch}')
    logging.info(f'max val p = {np.max(val_p_list)}  epoch {np.argmax(val_p_list) + cfg.start_epoch}')
    logging.info(f'max val r = {np.max(val_r_list)}  epoch {np.argmax(val_r_list) + cfg.start_epoch}')
    logging.info(f'max val ap = {np.max(val_ap_list)}  epoch {np.argmax(val_ap_list) + cfg.start_epoch}')

    # 保存 tensorboardX 文件
    if os.path.exists(os.path.join(save_dir, time_str)):
        shutil.rmtree(os.path.join(save_dir, time_str))
    shutil.copytree(os.path.join('./tensorboardX', time_str), os.path.join(save_dir, time_str))

    try:
        # 保存结果图片
        plt.figure()
        plt.plot(list(range(cfg.start_epoch, cfg.start_epoch + len(train_loss_list))), train_loss_list, c='b', label='train_loss')
        plt.plot(list(range(cfg.start_epoch, cfg.start_epoch + len(train_loss_list))), val_loss_list, c='y', label='val_loss')
        plt.xlabel('epoch')
        plt.ylabel('loss')
        plt.legend()
        plt.savefig(os.path.join(save_dir, 'loss.png'))

        plt.figure()
        plt.plot(list(range(cfg.start_epoch, cfg.start_epoch + len(train_loss_list))), train_acc_list, c='b', label='train_acc')
        plt.plot(list(range(cfg.start_epoch, cfg.start_epoch + len(train_loss_list))), val_acc_list, c='y', label='val_acc')
        plt.xlabel('epoch')
        plt.ylabel('accuracy')
        plt.legend()
        plt.savefig(os.path.join(save_dir, 'acc.png'))

        plt.figure()
        plt.plot(list(range(cfg.start_epoch, cfg.start_epoch + len(train_loss_list))), train_auc_list, c='b', label='train_auc')
        plt.plot(list(range(cfg.start_epoch, cfg.start_epoch + len(train_loss_list))), val_auc_list, c='y', label='val_auc')
        plt.xlabel('epoch')
        plt.ylabel('auc')
        plt.legend()
        plt.savefig(os.path.join(save_dir, 'auc.png'))

        plt.figure()
        plt.plot(list(range(cfg.start_epoch, cfg.start_epoch + len(train_loss_list))), train_ap_list, c='b',
                 label='train_ap')
        plt.plot(list(range(cfg.start_epoch, cfg.start_epoch + len(train_loss_list))), val_ap_list, c='y', label='val_ap')
        plt.xlabel('epoch')
        plt.ylabel('ap')
        plt.legend()
        plt.savefig(os.path.join(save_dir, 'ap.png'))

        plt.figure()
        plt.plot(list(range(cfg.start_epoch, cfg.start_epoch + len(train_loss_list))), train_f1_list, c='b', label='train_f1')
        plt.plot(list(range(cfg.start_epoch, cfg.start_epoch + len(train_loss_list))), val_f1_list, c='y', label='val_f1')
        plt.xlabel('epoch')
        plt.ylabel('f1')
        plt.legend()
        plt.savefig(os.path.join(save_dir, 'f1.png'))

        plt.figure()
        plt.plot(list(range(cfg.start_epoch, cfg.start_epoch + len(train_loss_list))), train_mcc_list, c='b', label='train_mcc')
        plt.plot(list(range(cfg.start_epoch, cfg.start_epoch + len(train_loss_list))), val_mcc_list, c='y', label='val_mcc')
        plt.xlabel('epoch')
        plt.ylabel('mcc')
        plt.legend()
        plt.savefig(os.path.join(save_dir, 'mcc.png'))

        plt.figure()
        plt.plot(list(range(cfg.start_epoch, cfg.start_epoch + len(train_loss_list))), train_iou_list, c='b', label='train_iou')
        plt.plot(list(range(cfg.start_epoch, cfg.start_epoch + len(train_loss_list))), val_iou_list, c='y', label='val_iou')
        plt.xlabel('epoch')
        plt.ylabel('iou')
        plt.legend()
        plt.savefig(os.path.join(save_dir, 'iou.png'))

        plt.figure()
        plt.plot(list(range(cfg.start_epoch, cfg.start_epoch + len(train_loss_list))), train_p_list, c='b',
                 label='train_precision')
        plt.plot(list(range(cfg.start_epoch, cfg.start_epoch + len(train_loss_list))), val_p_list, c='y', label='val_precision')
        plt.xlabel('epoch')
        plt.ylabel('precision')
        plt.legend()
        plt.savefig(os.path.join(save_dir, 'precision.png'))

        plt.figure()
        plt.plot(list(range(cfg.start_epoch, cfg.start_epoch + len(train_loss_list))), train_r_list, c='b',
                 label='train_recall')
        plt.plot(list(range(cfg.start_epoch, cfg.start_epoch + len(train_loss_list))), val_r_list, c='y',
                 label='val_recall')
        plt.xlabel('epoch')
        plt.ylabel('recall')
        plt.legend()
        plt.savefig(os.path.join(save_dir, 'recall.png'))
    except Exception as e:
        print(repr(e))

    max_epochs = [f'epoch_{np.argmax(i) + cfg.start_epoch}.pth' for i in [val_auc_list, val_f1_list, val_mcc_list, val_iou_list, val_acc_list, val_p_list, val_r_list, val_ap_list]]
    epoch_files = os.listdir(os.path.join(save_dir, 'pth'))
    for i in epoch_files:
        if i in max_epochs:
            continue
        else:
            os.remove(os.path.join(save_dir, 'pth', i))