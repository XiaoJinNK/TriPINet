import os
import torch
from torch import optim
import torchvision.transforms as T


class Config:
    """
    CASIAv1.0:
    h_stat Counter({256: 389, 384: 70, 246: 1, 500: 1})
    w_stat Counter({384: 390, 256: 70, 334: 1})

    CASIAv2.0:
    h_stat Counter({256: 2743, 384: 574, 480: 190, 600: 158, 450: 62, 390: 59, 402: 58, 375: 56, 518: 46, ...}
    w_stat Counter({384: 2746, 256: 571, 800: 387, 600: 300, 640: 179, 550: 126, 500: 85, 561: 59, ...}
    """

    def __init__(self):
        super(Config, self).__init__()

        self.dp = Dataset_Path()

        '''Input Data'''
        '''预训练'''
        # self.data_txt_list = [self.dp.synthetic_img_txt]
        # self.mask_txt_list = [self.dp.synthetic_mask_txt]
        # self.data_num_list = [17295]

        '''CASIAv2'''
        self.train_img_txt_list = self.dp.CASIAv2_train_img
        self.train_mask_txt_list = self.dp.CASIAv2_train_mask
        # self.train_img_txt_list = self.dp.CASIA_augTrain_img
        # self.train_mask_txt_list = self.dp.CASIA_augTrain_mask
        self.val_img_txt_list = self.dp.CASIAv2_val_img
        self.val_mask_txt_list = self.dp.CASIAv2_val_mask
        self.test_img_txt_list = self.dp.CASIAv2_test_img
        self.test_mask_txt_list = self.dp.CASIAv2_test_mask
        # self.data_num_list = None

        '''CASIAv1 SP'''
        # self.train_img_txt_list = self.dp.COLUMB_train_img
        # self.train_mask_txt_list = self.dp.COLUMB_train_mask
        # self.val_img_txt_list = self.dp.COLUMB_val_img
        # self.val_mask_txt_list = self.dp.COLUMB_val_mask
        # self.test_img_txt_list = self.dp.COLUMB_test_img
        # self.test_mask_txt_list = self.dp.COLUMB_test_mask
        # self.data_num_list = None

        # self.train_img_txt_list = self.dp.Carvalho_train_img
        # self.train_mask_txt_list = self.dp.Carvalho_train_mask
        # self.val_img_txt_list = self.dp.Carvalho_val_img
        # self.val_mask_txt_list = self.dp.Carvalho_val_mask
        # self.test_img_txt_list = self.dp.Carvalho_test_img
        # self.test_mask_txt_list = self.dp.Carvalho_test_mask
        # self.data_num_list = None

        # CASIAv2 SP
        # self.data_txt_list = [self.dp.CASIAv2_SP_img_txt]
        # self.mask_txt_list = [self.dp.CASIAv2_SP_mask_txt]
        # self.data_num_list = [1828]

        # CASIAv2 SP
        # self.data_txt_list = [self.dp.CASIAv2_CM_img_txt]
        # self.mask_txt_list = [self.dp.CASIAv2_CM_mask_txt]
        # self.data_num_list = [3295]

        '''fine-tune'''
        # self.data_txt_list = [self.dp.NIST16_train_img_txt]
        # self.mask_txt_list = [self.dp.NIST16_train_mask_txt]
        # self.data_num_list = [404]
        # self.data_txt_list = [self.dp.COVER_train_img_txt]
        # self.mask_txt_list = [self.dp.COVER_train_mask_txt]
        # self.data_num_list = [75]

        '''threashold'''
        self.train_threshold = 0.5

        '''Split Data'''
        # self.p_train = 0.95
        # self.p_val = 0.05

        '''Data Preprocessing'''
        self.num_workers = 8  # torch.utils.data_protocol.DataLoader 的 num_workers 参数，win10设置为8会出现诡异错误

        # 上插值虽然没增加篡改像素比例，但是增大了实际的篡改区域有助于训练？？？
        self.img_h, self.img_w = 256, 256
        # self.img_h, self.img_w = 512, 512
        self.img_transform_list = [T.Resize((self.img_h, self.img_w))]
        self.mask_transform_list = [T.Resize((self.img_h, self.img_w))]

        '''Save Paths'''
        self.is_FineTune = False
        self.result_path = '/media/ubuntu/hdd/ForensicNet_result/SOTA/CASIAv2'
        self.dir_name = '2022-06-24-3080ti-1#1-vgg16_bn-CASIAv2_SP_CM-3GAP_2GMP-SOTA-3'
        if self.is_FineTune:
            self.save_dir = os.path.join(self.result_path, self.dir_name + '-finetune-NIST16-#1-0516')
        else:
            self.save_dir = os.path.join(self.result_path, self.dir_name)

        '''training parameters'''
        self.CUDA = True
        self.device = torch.device('cuda' if self.CUDA else 'cpu')

        self.data_aug = True
        self.epochs = 150
        self.batch_size = 16

        '''model'''
        from net.vgg.Net import Net
        self.skip_connection = True
        self.model = Net(model='vgg16_bn',
                         skip_connection=self.skip_connection)

        # 设置时间戳，用于保存TensorBoardX数据
        self.time_str = None
        # self.time_str = '2022-01-04_10-16-08'

        # 是否继续训练
        # self.model_pth = '/media/ubuntu/hdd/ForensicNet_result/2022-05-22-3080ti#2-CASIAv2-vgg11_bn-3GAP_2GMP-bayarSRM-onlyBCE/pth/epoch_88.pth'
        # self.model_pth = os.path.join(self.result_path, self.dir_name,  'pth', 'epoch_81.pth')
        self.model_pth = None
        self.start_epoch = 1

        '''optimizer'''
        self.optimizer = optim.Adam
        # self.weight_decay = 1e-2
        # self.weight_decay = 1e-3
        # self.weight_decay = 1e-4
        self.weight_decay = 5e-4
        # self.weight_decay = 0       # Adam default parameter
        # self.beta = (0.9, 0.999)    # Adam default parameter

        '''lr_scheduler'''
        # self.lr_scheduler = None
        # self.lr_scheduler = optim.lr_scheduler.StepLR
        # self.step_size = 10
        # self.gamma = 0.5
        self.hloss_T = self.epochs
        self.learning_rate = 1e-3
        self.min_lr = 1e-7
        self.warmup_epoch = 5
        self.auto_lr_down_step = 5
        self.auto_lr_down_rate = 0.5

        '''loss'''
        from utils.loss import HybridLossWithLogits_pure
        # self.pos_weight = None
        # self.criterion_pixel = torch.nn.BCEWithLogitsLoss(pos_weight=self.pos_weight).to(self.device)
        self.criterion_pixel = HybridLossWithLogits_pure().to(self.device)


class Dataset_Path:
    def __init__(self):
        super(Dataset_Path, self).__init__()

        '''dataset paths'''
        # 数据集 txt 文件夹
        self.data_dir = '/home/ubuntu/lwy/Forensics-Dataset'
        self.txt_dir = '/home/ubuntu/lwy/data'

        '''pre-training dataset'''
        # DEFATCO
        self.DEFATCO_SP_img_1_txt = os.path.join(self.txt_dir, 'DEFATCO/SP_img_1.txt')
        self.DEFATCO_SP_img_2_txt = os.path.join(self.txt_dir, 'DEFATCO/SP_img_2.txt')
        self.DEFATCO_SP_img_3_txt = os.path.join(self.txt_dir, 'DEFATCO/SP_img_3.txt')
        self.DEFATCO_SP_img_4_txt = os.path.join(self.txt_dir, 'DEFATCO/SP_img_4.txt')
        self.DEFATCO_SP_img_5_txt = os.path.join(self.txt_dir, 'DEFATCO/SP_img_5.txt')
        self.DEFATCO_SP_img_6_txt = os.path.join(self.txt_dir, 'DEFATCO/SP_img_6.txt')
        self.DEFATCO_SP_img_7_txt = os.path.join(self.txt_dir, 'DEFATCO/SP_img_7.txt')
        self.DEFATCO_SP_mask_1_txt = os.path.join(self.txt_dir, 'DEFATCO/SP_mask_1.txt')
        self.DEFATCO_SP_mask_2_txt = os.path.join(self.txt_dir, 'DEFATCO/SP_mask_2.txt')
        self.DEFATCO_SP_mask_3_txt = os.path.join(self.txt_dir, 'DEFATCO/SP_mask_3.txt')
        self.DEFATCO_SP_mask_4_txt = os.path.join(self.txt_dir, 'DEFATCO/SP_mask_4.txt')
        self.DEFATCO_SP_mask_5_txt = os.path.join(self.txt_dir, 'DEFATCO/SP_mask_5.txt')
        self.DEFATCO_SP_mask_6_txt = os.path.join(self.txt_dir, 'DEFATCO/SP_mask_6.txt')
        self.DEFATCO_SP_mask_7_txt = os.path.join(self.txt_dir, 'DEFATCO/SP_mask_7.txt')
        self.DEFATCO_CM_img_txt = os.path.join(self.txt_dir, 'DEFATCO/CM_img.txt')
        self.DEFATCO_CM_mask_txt = os.path.join(self.txt_dir, 'DEFATCO/CM_mask.txt')

        # Synthetic-HLED 17295
        self.synthetic_img_txt = '/home/ubuntu/lwy/Forensics-Dataset/Synthetic-HLED/synthetic_HLED_img.txt'
        self.synthetic_mask_txt = '/home/ubuntu/lwy/Forensics-Dataset/Synthetic-HLED/synthetic_HLED_mask.txt'

        '''fine-tuning dataset'''
        # CASIA v2.0
        # 5123
        self.CASIAv2_img_txt = os.path.join(self.txt_dir, 'CASIA_v2/img.txt')
        self.CASIAv2_mask_txt = os.path.join(self.txt_dir, 'CASIA_v2/mask.txt')
        # SP 1828
        self.CASIAv2_SP_img_txt = os.path.join(self.txt_dir, 'CASIA_v2/SP_img.txt')
        self.CASIAv2_SP_mask_txt = os.path.join(self.txt_dir, 'CASIA_v2/SP_mask.txt')
        # CM 3295
        self.CASIAv2_CM_img_txt = os.path.join(self.txt_dir, 'CASIA_v2/CM_img.txt')
        self.CASIAv2_CM_mask_txt = os.path.join(self.txt_dir, 'CASIA_v2/CM_mask.txt')
        # self.CASIAv2_edge_txt = os.path.join(self.txt_dir, 'CASIA_v2/edge.txt')

        '''test data_protocol'''
        # CASIAv1.0
        # 920
        self.CASIAv1_img_txt = os.path.join(self.txt_dir, 'CASIA_v1/img.txt')
        self.CASIAv1_img_modified_txt = os.path.join(self.txt_dir, 'CASIA_v1/img_modified.txt')
        self.CASIAv1_mask_txt = os.path.join(self.txt_dir, 'CASIA_v1/mask.txt')
        # 461
        self.CASIAv1_SP_txt = os.path.join(self.txt_dir, 'CASIA_v1/SP_img.txt')
        self.CASIAv1_SP_modified_txt = os.path.join(self.txt_dir, 'CASIA_v1/SP_modified_img.txt')
        self.CASIAv1_SP_mask_txt = os.path.join(self.txt_dir, 'CASIA_v1/SP_mask.txt')
        # 459
        self.CASIAv1_CM_txt = os.path.join(self.txt_dir, 'CASIA_v1/CM_img.txt')
        self.CASIAv1_CM_modified_txt = os.path.join(self.txt_dir, 'CASIA_v1/CM_modified_img.txt')
        self.CASIAv1_CM_mask_txt = os.path.join(self.txt_dir, 'CASIA_v1/CM_mask.txt')

        # COLUMB
        # 180
        self.COLUMB_img_txt = os.path.join(self.txt_dir, 'COLUMB/img.txt')
        self.COLUMB_mask_txt = os.path.join(self.txt_dir, 'COLUMB/mask.txt')

        # COVER
        # 91
        self.COVER_img_txt = os.path.join(self.txt_dir, 'COVERAGE/img.txt')
        self.COVER_mask_txt = os.path.join(self.txt_dir, 'COVERAGE/mask.txt')
        # 75
        self.COVER_train_img_txt = '/home/ubuntu/lwy/data_protocol/COVER/COVER_train_img.txt'
        self.COVER_train_mask_txt = '/home/ubuntu/lwy/data_protocol/COVER/COVER_train_mask.txt'
        # 16
        self.COVER_test_img_txt = '/home/ubuntu/lwy/data_protocol/COVER/COVER_test_img.txt'
        self.COVER_test_mask_txt = '/home/ubuntu/lwy/data_protocol/COVER/COVER_test_mask.txt'

        # NIST16
        # 564
        self.NIST16_img_txt = os.path.join(self.txt_dir, 'NIST2016/manipulation_img.txt')
        self.NIST16_mask_txt = os.path.join(self.txt_dir, 'NIST2016/manipulation_mask.txt')
        # 404
        self.NIST16_train_img_txt = '/home/ubuntu/lwy/data_protocol/NIST16/NIST16_train_img.txt'
        self.NIST16_train_mask_txt = '/home/ubuntu/lwy/data_protocol/NIST16/NIST16_train_mask.txt'
        # 160
        self.NIST16_test_img_txt = '/home/ubuntu/lwy/data_protocol/NIST16/NIST16_test_img.txt'
        self.NIST16_test_mask_txt = '/home/ubuntu/lwy/data_protocol/NIST16/NIST16_test_mask.txt'

        # Carvalho
        self.Carvalho_img_txt = '/home/ubuntu/lwy/data/DSO-1/img.txt'
        self.Carvalho_mask_txt = '/home/ubuntu/lwy/data/DSO-1/mask.txt'

        # [2021 TCSVT] Multi-task SE-Network for Image Splicing Localization
        # CASIAv2:  train : val : test = 4500 : 122 : 501
        self.CASIAv2_train_img = './data/CASIAv2/train_img.txt'
        self.CASIAv2_train_mask = './data/CASIAv2/train_mask.txt'
        self.CASIA_augTrain_img = '/home/ubuntu/lwy/Forensics-Dataset/CASIA_v2.0_revised_20220517/aug_CASIAv2_SP/img.txt'
        self.CASIA_augTrain_mask = '/home/ubuntu/lwy/Forensics-Dataset/CASIA_v2.0_revised_20220517/aug_CASIAv2_SP/mask.txt'
        self.CASIAv2_val_img = './data/CASIAv2/val_img.txt'
        self.CASIAv2_val_mask = './data/CASIAv2/val_mask.txt'
        self.CASIAv2_test_img = './data/CASIAv2/test_img.txt'
        self.CASIAv2_test_mask = './data/CASIAv2/test_mask.txt'
        # CASIAv1 SP:  train: 341  val:20  test: 100
        self.CASIAv1_train_img = './data/CASIAv1/train_img.txt'
        self.CASIAv1_train_mask = './data/CASIAv1/train_mask.txt'
        self.CASIAv1_val_img = './data/CASIAv1/val_img.txt'
        self.CASIAv1_val_mask = './data/CASIAv1/val_mask.txt'
        self.CASIAv1_test_img = './data/CASIAv1/test_img.txt'
        self.CASIAv1_test_mask = './data/CASIAv1/test_mask.txt'
        # COLUMB:  train: 125  val:5  test: 50
        # self.COLUMB_train_img = './data/COLUMB/train_img.txt'
        # self.COLUMB_train_mask = './data/COLUMB/train_mask.txt'
        self.COLUMB_train_img = './data/COLUMB/img_txt_all.txt'
        self.COLUMB_train_mask = './data/COLUMB/mask_txt_all.txt'
        self.COLUMB_val_img = './data/COLUMB/val_img.txt'
        self.COLUMB_val_mask = './data/COLUMB/val_mask.txt'
        self.COLUMB_test_img = './data/COLUMB/test_img.txt'
        self.COLUMB_test_mask = './data/COLUMB/test_mask.txt'
        # Carvalho:  train: 70  val:10  test: 20
        self.Carvalho_train_img = './data/Carvalho/train_img.txt'
        self.Carvalho_train_mask = './data/Carvalho/train_mask.txt'
        self.Carvalho_val_img = './data/Carvalho/val_img.txt'
        self.Carvalho_val_mask = './data/Carvalho/val_mask.txt'
        self.Carvalho_test_img = './data/Carvalho/test_img.txt'
        self.Carvalho_test_mask = './data/Carvalho/test_mask.txt'



        # # fine-tuning protocol
        # self.fine_tune_img = [self.NIST16_train_img_txt, self.CASIAv2_img_txt, self.COVER_train_img_txt]
        # self.fine_tune_mask = [self.NIST16_train_mask_txt, self.CASIAv2_mask_txt, self.COVER_train_mask_txt]
        #
        # # testing protocol
        # self.test_img = [self.NIST16_test_img_txt, self.CASIAv1_img_txt, self.COLUMB_img_txt, self.COVER_test_img_txt]
        # self.test_mask = [self.NIST16_test_mask_txt, self.CASIAv1_mask_txt, self.COLUMB_mask_txt, self.COVER_test_mask_txt]