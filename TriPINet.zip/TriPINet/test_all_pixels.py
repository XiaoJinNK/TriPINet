import os

import cv2
import pickle

import numpy as np
from tqdm import tqdm

from PIL import Image
import matplotlib.pyplot as plt

import torchvision
import torchvision.transforms as transforms

from config import Config
from utils.metrics import *
from utils.tools import get_preds_mask, get_preds_prob_map


def infer_test_data(model, test_data_lines, test_mask_lines=None, resize=(512, 512), device='cuda'):
    """
    :param model:
    :param test_data_lines:
    :param test_mask_lines:
    :param resize: None or (H, W)
    :param mask_temp_pix_1: True or False
    :param save_result_path: None or str
    :return: mcc_list, f1_list, acc_list
    """
    auc_list, ap_list = [], []
    tp_list, tn_list, fp_list, fn_list = [0] * 9, [0] * 9, [0] * 9, [0] * 9
    for ind, test_data_line in enumerate(tqdm(test_data_lines)):
        # print(test_data_line.strip())
        img_BGR = cv2.imread(test_data_line.strip(), flags=cv2.IMREAD_COLOR)
        img_name = test_data_line.strip().split('/')[-1].split('.')[0]
        img = cv2.cvtColor(img_BGR, code=cv2.COLOR_BGR2RGB)
        img_PIL = Image.fromarray(img)
        if resize:
            transform = torchvision.transforms.Compose([
                torchvision.transforms.Resize(resize),
                torchvision.transforms.ToTensor(),
                lambda x: x.unsqueeze(dim=0)
            ])
        else:
            transform = torchvision.transforms.Compose([
                torchvision.transforms.ToTensor(),
                lambda x: x.unsqueeze(dim=0)
            ])

        img_tensor = transform(img_PIL).to(device)
        logits = model(img_tensor)[-1].detach().to('cpu')

        if test_mask_lines is not None:
            # print(test_mask_lines[ind])
            mask = cv2.imread(test_mask_lines[ind].strip(), flags=cv2.IMREAD_GRAYSCALE)
            mask = torch.tensor(mask, dtype=torch.int).unsqueeze(0)  # (H, W)
            if resize:
                mask = transforms.Resize(resize)(mask)
            # 保持生成的mask篡改像素值为1
            mask[np.where(mask < 128)] = 0
            mask[np.where(mask >= 128)] = 1

            if len(logits.shape) != 3:
                logits = logits.reshape(logits.shape[0], logits.shape[2], logits.shape[3])
            if len(mask.shape) != 3:
                mask = mask.reshape(mask.shape[0], mask.shape[2], mask.shape[3])

            auc = AUC(get_preds_prob_map(logits), mask)
            auc_list.append(auc[0])
            ap = AP(get_preds_prob_map(logits), mask)
            ap_list.append(ap[0])

            for i, threshold in enumerate(np.arange(0.1, 1.0, 0.1)):
                pred_mask = get_preds_mask(logits, threshold=threshold)
                tp, tn, fp, fn = get_tp_tn_fp_fn(pred_mask, mask)
                tp = tp.sum()
                tn = tn.sum()
                fp = fp.sum()
                fn = fn.sum()
                # print(tp, tn, fp, fn)
                tp_list[i] += tp
                tn_list[i] += tn
                fp_list[i] += fp
                fn_list[i] += fn

    tp = np.array(tp_list)
    tn = np.array(tn_list)
    fp = np.array(fp_list)
    fn = np.array(fn_list)

    auc = np.mean(auc_list)
    ap = np.mean(ap_list)
    f1 = np.max(2 * tp / (2 * tp + fp + fn))
    mcc = np.max(matthews_correlation_coefficient((tp, tn, fp, fn)))
    iou = np.max(tp / (tp + fp + fn))
    acc = np.max((tp + tn) / (tp + tn + fp + fn))
    p = np.max(tp / (tp + fp))
    r = np.max(tp / (tp + fn))
    best_threshold = np.argmax(f1) * 0.1 + 0.1

    return auc, f1, mcc, iou, acc, p, r, ap, best_threshold


def test():
    '''test CASIAv1 Modified images'''
    img_txt = cfg.test_img_txt_list
    mask_txt = cfg.test_mask_txt_list
    with open(img_txt, 'r') as f:
        data_lines = f.readlines()
    with open(mask_txt, 'r') as f:
        mask_lines = f.readlines()
    auc, f1, mcc, iou, acc, p, r, ap, best_threshold = infer_test_data(model, data_lines, mask_lines, resize=resize,
                                                                   device='cuda')
    with open(result_txt, 'a', encoding='utf-8') as f:
        f.write(f'auc: {auc}\n')
        f.write(f'ap: {ap}\n')
        f.write(f'f1: {f1}\n')
        f.write(f'mcc: {mcc}\n')
        f.write(f'iou: {iou}\n')
        f.write(f'acc: {acc}\n')
        f.write(f'p: {p}\n')
        f.write(f'r: {r}\n')
    print('auc:', auc)
    print('ap:', ap)
    print('f1:', f1)
    print('mcc:', mcc)
    print('iou:', iou)
    print('acc:', acc)
    print('p:', p)
    print('r:', r)



'''main'''
if __name__ == '__main__':

    cfg = Config()

    dir_1 = '/media/ubuntu/hdd/ForensicNet_result/SOTA/CASIAv2'
    # dir_2 = '2022-06-09-3080ti#2-vgg11_bn-CASIAv2_SP_CM-CMDA_mid_1*1_wo_Relu_wo_bn-freqency_wo_bn_relu'
    dir_2 = cfg.dir_name
    pth_file = 'epoch_65.pth'

    # test_threshold = 0.5
    test_threshold = 'best'

    dir_3 = 'pixel-test_threshold=' + str(test_threshold) + '_resize256'

    resize = (256, 256)
    # resize = None

    model = cfg.model.to('cuda')
    model.load_state_dict(torch.load(os.path.join(dir_1, dir_2, 'pth', pth_file)))
    print('load state corretly...')
    model.eval()

    # dir_2 = '2022-04-20-3080ti#1-add-posw2-skip-pretrain-finetune'
    os.makedirs(os.path.join(dir_1, dir_2, dir_3), exist_ok=True)
    result_txt = os.path.join(dir_1, dir_2, dir_3, f'test_result_{test_threshold}.txt')
    if not os.path.exists(result_txt):
        with open(result_txt, 'w'):
            pass

    test()






'''test NIST2016 images'''
# img_txt = cfg.NIST2016_Manipulation_img_txt
# mask_txt = cfg.NIST2016_Manipulation_mask_txt
# save_dir = 'NIST2016_result'
# save_result_path = os.path.join(dir_1, dir_2, save_dir)
# with open(img_txt, 'r') as f:
#     data_lines = f.readlines()
# with open(mask_txt, 'r') as f:
#     mask_lines = f.readlines()
# mcc_list, f1_list, acc_list = infer_test_data(model, data_lines, mask_lines,
#                                               resize=None,
#                                               mask_temp_pix_1=False,
#                                               save_result_path=save_result_path,
#                                               device='cpu')
# print('mcc:', mcc)
# print('f1:', f1)
# print('acc:', acc)





