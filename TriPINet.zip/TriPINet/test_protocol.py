import os

import cv2
import pickle

import numpy as np
import torch
from tqdm import tqdm

from PIL import Image
import matplotlib.pyplot as plt

import torchvision
import torchvision.transforms as transforms

from config import Config
from utils.metrics import *
from utils.tools import get_preds_mask, get_preds_prob_map, get_dataloader


def infer_test_data(model, test_data_lines, test_mask_lines, img_transform_list=None, mask_transform_list=None,
                    save_result_path=None, device='cuda'):
    """
    :param model:
    :param test_data_lines:
    :param test_mask_lines:
    :param resize: None or (H, W)
    :param mask_temp_pix_1: True or False
    :param save_result_path: None or str
    :return: mcc_list, f1_list, acc_list
    """
    os.makedirs(save_result_path, exist_ok=True)
    auc_list, f1_list, mcc_list, iou_list, acc_list, p_list, r_list, ap_list = [], [], [], [], [], [], [], []
    testloader = get_dataloader(test_data_lines, test_mask_lines, batch_size=1, shuffle=False, data_aug=False,
                                img_transform_list=img_transform_list,
                                mask_transform_list=mask_transform_list)
    for ind, (img, mask) in tqdm(list(enumerate(testloader))):
        img = img.to(device)
        logits = model(img)[-1].detach().to('cpu')
        aucs, f1s, mccs, ious, accs, ps, rs, aps, thresholds = get_metrics(logits, mask, threshold=test_threshold)
        auc = float(aucs[0])
        f1 = float(f1s[0])
        mcc = float(mccs[0])
        iou = float(ious[0])
        acc = float(accs[0])
        p = float(ps[0])
        r = float(rs[0])
        ap = float(aps[0])
        auc_list.append(auc)
        f1_list.append(f1)
        mcc_list.append(mcc)
        iou_list.append(iou)
        acc_list.append(acc)
        p_list.append(p)
        r_list.append(r)
        ap_list.append(ap)

        plt.figure()
        plt.subplot(1, 2, 1)
        plt.title('mask')
        plt.imshow(mask.squeeze(0).squeeze(0), cmap='gray')
        plt.subplot(1, 2, 2)
        plt.title('preds_mask')
        preds_mask = get_preds_mask(logits, threshold=thresholds)
        plt.imshow(preds_mask.squeeze(0).squeeze(0), cmap='gray')
        tp, tn, fp, fn = get_tp_tn_fp_fn(preds_mask.squeeze(0), mask.squeeze(0))
        plt.title('auc: {:.2f}  f1: {:.2f}  mcc: {:.2f}  iou: {:.2f}\nap: {:.2f}  acc: {:.2f}'.format(auc, f1, mcc, iou, ap, acc) +
                  'threshold: {:.1f}\n'.format(thresholds) +
                  f'TP: {int(tp)}  TN: {int(tn)}  FP: {int(fp)}  FN: {int(fn)}')

        # print(os.path.join(save_result_path, img_name + '.png'))
        plt.savefig(os.path.join(save_result_path, str(ind) + '.png'))
        plt.close()
    return auc_list, f1_list, mcc_list, iou_list, acc_list, p_list, r_list, ap_list


#
# def test(dir_1, dir_2, dir_3):
#     dir_path = os.path.join(dir_1, dir_2, dir_3)
#
#     '''test CASIAv1 Modified images'''
#     print('\n\nCASIAv1 Modified')
#     img_txt = cfg.dp.CASIAv1_img_modified_txt
#     mask_txt = cfg.dp.CASIAv1_mask_txt
#     save_dir = 'CASIAv1_Modified_result'
#     save_result_path = os.path.join(dir_path, save_dir)
#     with open(img_txt, 'r') as f:
#         data_lines = f.readlines()
#     with open(mask_txt, 'r') as f:
#         mask_lines = f.readlines()
#     auc_list, f1_list, mcc_list, iou_list, acc_list = infer_test_data(model, data_lines, mask_lines,
#                                                                       resize=resize,
#                                                                       save_result_path=save_result_path,
#                                                                       device='cuda')
#     with open(result_txt, 'a', encoding='utf-8') as f:
#         f.write('CASIAv1 Modified:\n')
#         f.write(f'mean auc: {np.mean(auc_list)}\n')
#         f.write(f'mean f1: {np.mean(f1_list)}\n')
#         f.write(f'mean mcc: {np.mean(mcc_list)}\n')
#         f.write(f'mean iou: {np.mean(iou_list)}\n')
#         f.write(f'mean acc: {np.mean(acc_list)}\n\n')
#     print('mean auc:', np.mean(auc_list))
#     print('mean f1:', np.mean(f1_list))
#     print('mean mcc:', np.mean(mcc_list))
#     print('mean iou:', np.mean(iou_list))
#     print('mean acc:', np.mean(acc_list))
#
#     '''test CASIAv1 Modified SP images'''
#     print('\n\nCASIAv1 Modified SP')
#     img_txt = cfg.dp.CASIAv1_SP_modified_txt
#     mask_txt = cfg.dp.CASIAv1_SP_MASK_txt
#     save_dir = 'CASIAv1_Modified_SP_result'
#     save_result_path = os.path.join(dir_path, save_dir)
#     with open(img_txt, 'r') as f:
#         data_lines = f.readlines()
#     with open(mask_txt, 'r') as f:
#         mask_lines = f.readlines()
#     auc_list, f1_list, mcc_list, iou_list, acc_list = infer_test_data(model, data_lines, mask_lines,
#                                                                       resize=resize,
#                                                                       save_result_path=save_result_path,
#                                                                       device='cuda')
#     with open(result_txt, 'a', encoding='utf-8') as f:
#         f.write('CASIAv1 Modified SP:\n')
#         f.write(f'mean auc: {np.mean(auc_list)}\n')
#         f.write(f'mean f1: {np.mean(f1_list)}\n')
#         f.write(f'mean mcc: {np.mean(mcc_list)}\n')
#         f.write(f'mean iou: {np.mean(iou_list)}\n')
#         f.write(f'mean acc: {np.mean(acc_list)}\n\n')
#     print('mean auc:', np.mean(auc_list))
#     print('mean f1:', np.mean(f1_list))
#     print('mean mcc:', np.mean(mcc_list))
#     print('mean iou:', np.mean(iou_list))
#     print('mean acc:', np.mean(acc_list))
#     #
#     '''test CASIAv1 Modified CM images'''
#     print('\n\nCASIAv1 Modified CM')
#     img_txt = cfg.dp.CASIAv1_CM_modified_txt
#     mask_txt = cfg.dp.CASIAv1_CM_MASK_txt
#     save_dir = 'CASIAv1_Modified_CM_result'
#     save_result_path = os.path.join(dir_path, save_dir)
#     with open(img_txt, 'r') as f:
#         data_lines = f.readlines()
#     with open(mask_txt, 'r') as f:
#         mask_lines = f.readlines()
#     auc_list, f1_list, mcc_list, iou_list, acc_list = infer_test_data(model, data_lines, mask_lines,
#                                                                       resize=resize,
#                                                                       save_result_path=save_result_path,
#                                                                       device='cuda')
#     with open(result_txt, 'a', encoding='utf-8') as f:
#         f.write('CASIAv1 Modified CM:\n')
#         f.write(f'mean auc: {np.mean(auc_list)}\n')
#         f.write(f'mean f1: {np.mean(f1_list)}\n')
#         f.write(f'mean mcc: {np.mean(mcc_list)}\n')
#         f.write(f'mean iou: {np.mean(iou_list)}\n')
#         f.write(f'mean acc: {np.mean(acc_list)}\n\n')
#     print('mean auc:', np.mean(auc_list))
#     print('mean f1:', np.mean(f1_list))
#     print('mean mcc:', np.mean(mcc_list))
#     print('mean iou:', np.mean(iou_list))
#     print('mean acc:', np.mean(acc_list))
#
#     '''test COVERAGE images'''
#     print('\n\nCOVER')
#     img_txt = cfg.dp.COVER_img_txt
#     mask_txt = cfg.dp.COVER_mask_txt
#     # img_txt = cfg.dp.COVER_test_img_txt
#     # mask_txt = cfg.dp.COVER_test_mask_txt
#     save_dir = 'COVERAGE_result'
#     save_result_path = os.path.join(dir_path, save_dir)
#     with open(img_txt, 'r') as f:
#         data_lines = f.readlines()
#     with open(mask_txt, 'r') as f:
#         mask_lines = f.readlines()
#     auc_list, f1_list, mcc_list, iou_list, acc_list = infer_test_data(model, data_lines, mask_lines,
#                                                                       resize=resize,
#                                                                       save_result_path=save_result_path,
#                                                                       device='cuda')
#     with open(result_txt, 'a', encoding='utf-8') as f:
#         f.write('COVER:\n')
#         f.write(f'mean auc: {np.mean(auc_list)}\n')
#         f.write(f'mean f1: {np.mean(f1_list)}\n')
#         f.write(f'mean mcc: {np.mean(mcc_list)}\n')
#         f.write(f'mean iou: {np.mean(iou_list)}\n')
#         f.write(f'mean acc: {np.mean(acc_list)}\n\n')
#     print('mean auc:', np.mean(auc_list))
#     print('mean f1:', np.mean(f1_list))
#     print('mean mcc:', np.mean(mcc_list))
#     print('mean iou:', np.mean(iou_list))
#     print('mean acc:', np.mean(acc_list))
#
#     '''test COLUMB images'''
#     print('\n\nCOLUMB')
#     img_txt = cfg.dp.COLUMB_img_txt
#     mask_txt = cfg.dp.COLUMB_mask_txt
#     save_dir = 'COLUMB_result'
#     save_result_path = os.path.join(dir_path, save_dir)
#     with open(img_txt, 'r') as f:
#         data_lines = f.readlines()
#     with open(mask_txt, 'r') as f:
#         mask_lines = f.readlines()
#     auc_list, f1_list, mcc_list, iou_list, acc_list = infer_test_data(model.to('cuda'), data_lines, mask_lines,
#                                                                       resize=resize,
#                                                                       save_result_path=save_result_path,
#                                                                       device='cuda')
#     with open(result_txt, 'a', encoding='utf-8') as f:
#         f.write('COLUMB:\n')
#         f.write(f'mean auc: {np.mean(auc_list)}\n')
#         f.write(f'mean f1: {np.mean(f1_list)}\n')
#         f.write(f'mean mcc: {np.mean(mcc_list)}\n')
#         f.write(f'mean iou: {np.mean(iou_list)}\n')
#         f.write(f'mean acc: {np.mean(acc_list)}\n\n')
#     print('mean auc:', np.mean(auc_list))
#     print('mean f1:', np.mean(f1_list))
#     print('mean mcc:', np.mean(mcc_list))
#     print('mean iou:', np.mean(iou_list))
#     print('mean acc:', np.mean(acc_list))
#
#     '''test NIST16 images'''
#     print('\n\nNIST16')
#     img_txt = cfg.dp.NIST16_img_txt
#     mask_txt = cfg.dp.NIST16_mask_txt
#     # img_txt = cfg.dp.NIST16_test_img_txt
#     # mask_txt = cfg.dp.NIST16_test_mask_txt
#     save_dir = 'NIST16_result'
#     save_result_path = os.path.join(dir_path, save_dir)
#     with open(img_txt, 'r') as f:
#         data_lines = f.readlines()
#     with open(mask_txt, 'r') as f:
#         mask_lines = f.readlines()
#     auc_list, f1_list, mcc_list, iou_list, acc_list = infer_test_data(model.to('cuda'), data_lines, mask_lines,
#                                                                       resize=(256, 256),
#                                                                       save_result_path=save_result_path,
#                                                                       device='cuda')
#     with open(result_txt, 'a', encoding='utf-8') as f:
#         f.write('NIST16:\n')
#         f.write(f'mean auc: {np.mean(auc_list)}\n')
#         f.write(f'mean f1: {np.mean(f1_list)}\n')
#         f.write(f'mean mcc: {np.mean(mcc_list)}\n')
#         f.write(f'mean iou: {np.mean(iou_list)}\n')
#         f.write(f'mean acc: {np.mean(acc_list)}\n\n')
#     print('mean auc:', np.mean(auc_list))
#     print('mean f1:', np.mean(f1_list))
#     print('mean mcc:', np.mean(mcc_list))
#     print('mean iou:', np.mean(iou_list))
#     print('mean acc:', np.mean(acc_list))





'''main'''
if __name__ == '__main__':

    cfg = Config()

    dir_1 = '/media/ubuntu/hdd/ForensicNet_result/SOTA/CASIAv2'
    # dir_2 = '2022-06-09-3080ti#2-vgg11_bn-CASIAv2_SP_CM-CMDA_mid_1*1_wo_Relu_wo_bn-freqency_wo_bn_relu'
    dir_2 = cfg.dir_name
    pth_file = 'epoch_65.pth'

    # test_threshold = 0.5
    test_threshold = 'best'

    dir_3 = f'{pth_file.split(".")[0]}-protocol-test_threshold=' + str(test_threshold) + '_resize256'

    resize = (256, 256)
    # resize = None

    model = cfg.model.to('cuda')
    model.load_state_dict(torch.load(os.path.join(dir_1, dir_2, 'pth', pth_file)))
    print('load state corretly...')
    model.eval()

    # dir_2 = '2022-04-20-3080ti#1-add-posw2-skip-pretrain-finetune'
    os.makedirs(os.path.join(dir_1, dir_2, dir_3), exist_ok=True)
    result_txt = os.path.join(dir_1, dir_2, f'test_result_{test_threshold}.txt')
    if not os.path.exists(result_txt):
        with open(result_txt, 'w'):
            pass

    auc_list, f1_list, mcc_list, iou_list, acc_list, p_list, r_list, ap_list = infer_test_data(model, cfg.test_img_txt_list,
                                                                                      cfg.test_mask_txt_list,
                                                                                      img_transform_list=cfg.img_transform_list,
                                                                                      mask_transform_list=cfg.mask_transform_list,
                                                                                      save_result_path=os.path.join(
                                                                                          dir_1, dir_2, dir_3))

    with open(result_txt, 'a') as f:
        f.write(f'auc: {np.mean(auc_list)}\n')
        f.write(f'ap: {np.mean(ap_list)}\n')
        f.write(f'f1: {np.mean(f1_list)}\n')
        f.write(f'mcc: {np.mean(mcc_list)}\n')
        f.write(f'iou: {np.mean(iou_list)}\n')
        f.write(f'acc: {np.mean(acc_list)}\n')
        f.write(f'p: {np.mean(p_list)}\n')
        f.write(f'r: {np.mean(r_list)}\n')

    print(f'auc: {np.mean(auc_list)}')
    print(f'ap: {np.mean(ap_list)}')
    print(f'f1: {np.mean(f1_list)}')
    print(f'mcc: {np.mean(mcc_list)}')
    print(f'iou: {np.mean(iou_list)}')
    print(f'acc: {np.mean(acc_list)}')
    print(f'p: {np.mean(p_list)}')
    print(f'r: {np.mean(r_list)}')

'''test NIST2016 images'''
# img_txt = cfg.NIST2016_Manipulation_img_txt
# mask_txt = cfg.NIST2016_Manipulation_mask_txt
# save_dir = 'NIST2016_result'
# save_result_path = os.path.join(dir_1, dir_2, save_dir)
# with open(img_txt, 'r') as f:
#     data_lines = f.readlines()
# with open(mask_txt, 'r') as f:
#     mask_lines = f.readlines()
# mcc_list, f1_list, acc_list = infer_test_data(model, data_lines, mask_lines,
#                                               resize=None,
#                                               mask_temp_pix_1=False,
#                                               save_result_path=save_result_path,
#                                               device='cpu')
# print('mean mcc:', np.mean(mcc_list))
# print('mean f1:', np.mean(f1_list))
# print('mean acc:', np.mean(acc_list))






