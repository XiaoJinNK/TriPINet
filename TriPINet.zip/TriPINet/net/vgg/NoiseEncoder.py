import torch.nn as nn
from net.vgg.RGBEncoder_VGGnet import VGGnet as RGBEncoder
from utils.img_transforms import rgb2gray
from net.Layers import BayarConv2d, SRMConv2d
import torch.nn.functional as F
import torch


class CombinedConv2d(nn.Module):
    def __init__(self, in_channels=3):
        super(CombinedConv2d, self).__init__()
        self.BayarConv2d = BayarConv2d(in_channels=in_channels, out_channels=3, padding=2)
        self.SRMConv2d = SRMConv2d(in_channels=in_channels, out_channels=3, stride=1, padding=2)

    def forward(self, X):
        # x1 = F.relu(self.BayarConv2d(X))
        # x2 = F.relu(self.SRMConv2d(X))
        x1 = self.BayarConv2d(X)
        x2 = self.SRMConv2d(X)
        return torch.cat([x1, x2], dim=1)


class CombinedConv2d_plus(nn.Module):
    def __init__(self, in_channels=3):
        super(CombinedConv2d_plus, self).__init__()
        self.BayarConv2d = BayarConv2d(in_channels=in_channels, out_channels=3, padding=2)
        self.SRMConv2d = SRMConv2d(in_channels=in_channels, out_channels=3, stride=1, padding=2)

    def forward(self, X):
        # x1 = F.relu(self.BayarConv2d(X))
        # x2 = F.relu(self.SRMConv2d(X))
        x1 = self.BayarConv2d(X)
        x2 = self.SRMConv2d(X)
        return x1 + x2


class NoiseEncoder(nn.Module):
    def __init__(self, model='vgg11_bn'):
        super(NoiseEncoder, self).__init__()

        # Bayar+SRM
        # self.noise_conv = CombinedConv2d(in_channels=3)
        # self.noise_extractor = RGBEncoder(model=model, has_first_layer=True, in_channel=6)
        self.noise_conv = CombinedConv2d_plus(in_channels=3)
        self.noise_extractor = RGBEncoder(model=model, has_first_layer=True, in_channel=3)

        # Bayar
        # self.noise_conv = BayarConv2d(in_channels=3, out_channels=3, padding=2)
        # self.noise_extractor = RGBEncoder(model=model, has_first_layer=True, in_channel=3)

        # SRM
        # self.noise_conv = SRMConv2d(in_channels=3, out_channels=3, stride=1, padding=2)
        # self.noise_extractor = RGBEncoder(model=model, has_first_layer=True, in_channel=3)

    def forward(self, x):
        # preprocess
        # x = rgb2gray(x)
        # network
        out_bayar = self.noise_conv(x)
        out1, out2, out3, out4, out5 = self.noise_extractor(out_bayar)

        # print(out1.shape)
        # print(out2.shape)
        # print(out3.shape)
        # print(out4.shape)
        # print(out5.shape)
        return out1, out2, out3, out4, out5


if __name__ == '__main__':
    from torchinfo import summary

    model = NoiseEncoder()
    summary(model, input_size=(1, 3, 256, 256), device='cpu')
