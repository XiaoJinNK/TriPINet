import torch.nn as nn
from net.vgg.NoiseEncoder import NoiseEncoder
from net.vgg.FreqEncoder import FreqEncoder
from net.vgg.RGBEncoder_VGGnet import VGGnet as RGBEncoder
from net.Decoders import Decoder_SENet
from net.Layers import CMTF, Residual_SE


class Net(nn.Module):
    def __init__(self, model='vgg16_bn', skip_connection=True):
        super(Net, self).__init__()

        # Encoder
        self.rgb_encoder = RGBEncoder(model=model, has_first_layer=True)
        stage_channels = self.rgb_encoder.get_stage_channels()

        self.freq_encoder = FreqEncoder(model=model, stage1_channel=stage_channels[0])
        self.noise_encoder = NoiseEncoder(model=model)

        # Fusion
        self.fusion1 = CMTF(out_channel=stage_channels[0])
        self.fusion2 = CMTF(out_channel=stage_channels[1])
        self.fusion3 = CMTF(out_channel=stage_channels[2])
        self.fusion4 = CMTF(out_channel=stage_channels[3])
        self.fusion5 = CMTF(out_channel=stage_channels[4])

        # Decoder
        # self.decoder = Decoder_Net(stage_channels, out_channel=1, skip_connection=skip_connection)
        self.decoder = Decoder_SENet(stage_channels, out_channel=1, skip_connection=skip_connection,
                                     SEBlock=Residual_SE)

        # Deep Supervision
        # dsi: i is decoder stage i
        self.dsfusion = nn.Sequential(
            nn.Conv2d(stage_channels[4], 1, kernel_size=3, padding=1),
            nn.UpsamplingBilinear2d(scale_factor=32)
        )
        self.ds1 = nn.Sequential(
            nn.Conv2d(stage_channels[3], 1, kernel_size=3, padding=1),
            nn.UpsamplingBilinear2d(scale_factor=16)
        )
        self.ds2 = nn.Sequential(
            nn.Conv2d(stage_channels[2], 1, kernel_size=3, padding=1),
            nn.UpsamplingBilinear2d(scale_factor=8)
        )
        self.ds3 = nn.Sequential(
            nn.Conv2d(stage_channels[1], 1, kernel_size=3, padding=1),
            nn.UpsamplingBilinear2d(scale_factor=4)
        )
        self.ds4 = nn.Sequential(
            nn.Conv2d(stage_channels[0], 1, kernel_size=3, padding=1),
            nn.UpsamplingBilinear2d(scale_factor=2)
        )

    def forward(self, x):
        # 4-elems tuple(out1, out2, out3, out4, out5)
        rgb_feature = self.rgb_encoder(x)
        freq_feature = self.freq_encoder(x)
        noise_feature = self.noise_encoder(x)

        # outi: encoder stage i
        out1 = self.fusion1(rgb_feature[0], freq_feature[0], noise_feature[0])
        out2 = self.fusion2(rgb_feature[1], freq_feature[1], noise_feature[1])
        out3 = self.fusion3(rgb_feature[2], freq_feature[2], noise_feature[2])
        out4 = self.fusion4(rgb_feature[3], freq_feature[3], noise_feature[3])
        out5 = self.fusion5(rgb_feature[4], freq_feature[4], noise_feature[4])

        # outi: decoder stage i
        out1, out2, out3, out4, logits = self.decoder((out1, out2, out3, out4, out5))

        # deep supervision
        fusion = self.dsfusion(out5)
        out1 = self.ds1(out1)
        out2 = self.ds2(out2)
        out3 = self.ds3(out3)
        out4 = self.ds4(out4)

        return fusion, out1, out2, out3, out4, logits


if __name__ == '__main__':
    from torchinfo import summary

    net = Net(model='vgg16_bn', skip_connection=True)
    summary(net, input_size=(1, 3, 256, 256), device='cpu')

    '''resnet34'''
    # == == == == == == == == == == == == == = == =
    # Total params: 90, 741, 716
    # Trainable params: 90, 741, 716
    # Non - trainable params: 0
    # Total mult - adds(G): 24.48
    # # == == == == == == == == =
    # Input size(MB): 0.79
    # Forward / backward pass size(MB): 362.55
    # Params size(MB): 362.97
    # Estimated Total Size(MB): 726.30
    # == == == == == == == ==

    '''resnet18'''
    # == == == == == == == == == == == == == ==  == ==
    # Total params: 60, 417, 236
    # Trainable params: 60, 417, 236
    # Non - trainable params: 0
    # Total mult - adds(G): 17.23
    # == == == == == == == == == ==
    # Input size(MB): 0.79
    # Forward / backward pass size(MB): 283.90
    # Params size(MB): 241.67
    # Estimated Total Size(MB): 526.36
    # == == == == == == == == == == ==  == == == ====
