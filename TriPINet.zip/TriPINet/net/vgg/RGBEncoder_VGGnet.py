import torch
from torch import nn
from torchvision import models


class VGGnet(nn.Module):
    def __init__(self, model='vgg11_bn', has_first_layer=True, in_channel=3):
        super(VGGnet, self).__init__()

        self.model = model
        if model == 'vgg11_bn':
            vgg = models.vgg11_bn(pretrained=True)
            layer_num = [4, 8, 15, 22, 29]
        elif model == 'vgg16_bn':
            vgg = models.vgg16_bn(pretrained=True)
            layer_num = [7, 14, 24, 34, 44]
        elif model == 'vgg19_bn':
            vgg = models.vgg19_bn(pretrained=True)
            layer_num = [7, 14, 27, 40, 53]
        else:
            # default resnet34
            vgg = models.vgg16_bn(pretrained=True)
            layer_num = [7, 14, 24, 34, 44]

        self.has_first_layer = has_first_layer

        # stage1
        if self.has_first_layer:
            self.stage1 = nn.Sequential(
                *[vgg.features[i] for i in range(layer_num[0])]
            )
        # stage 2
        self.stage2 = nn.Sequential(
            *[vgg.features[i] for i in range(layer_num[0], layer_num[1])]
        )
        # stage 3
        self.stage3 = nn.Sequential(
            *[vgg.features[i] for i in range(layer_num[1], layer_num[2])]
        )
        # stage 4
        self.stage4 = nn.Sequential(
            *[vgg.features[i] for i in range(layer_num[2], layer_num[3])]
        )
        # stage 5
        self.stage5 = nn.Sequential(
            *[vgg.features[i] for i in range(layer_num[3], layer_num[4])]
        )

        if self.has_first_layer:
            # 修改第一层卷积的输入通道数
            out_channel = self.stage1[0].out_channels
            self.stage1[0] = nn.Conv2d(in_channels=in_channel, out_channels=out_channel, kernel_size=3, stride=1,
                                       padding=1)

    def forward(self, x):
        if self.has_first_layer:
            out1 = self.stage1(x)
        else:
            out1 = x
        out2 = self.stage2(out1)
        out3 = self.stage3(out2)
        out4 = self.stage4(out3)
        out5 = self.stage5(out4)

        # torch.Size([1, 64, 128, 128])
        # torch.Size([1, 256, 64, 64])
        # torch.Size([1, 512, 32, 32])
        # torch.Size([1, 1024, 16, 16])
        # torch.Size([1, 2048, 8, 8])
        return out1, out2, out3, out4, out5

    def get_stage_channels(self):
        stage_channels = [64, 128, 256, 512, 512]
        return stage_channels


if __name__ == '__main__':
    from torchinfo import summary

    # model = VGGnet(model='vgg16_bn', has_first_layer=True)
    # summary(model, input_size=(1, 3, 256, 256), device='cpu')

    # model = models.vgg11_bn(pretrained=False)
    # print(model)
    model = models.vgg11(pretrained=False)
    print(model)

    # state = torch.load(r'C:\Users\CRRCOO\.cache\torch\hub\checkpoints\vgg16_bn-6c64b313.pth')
    # print(state['features.0.weight'] == model.stage1[0].weight)

