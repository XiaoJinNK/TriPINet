import torch
import torch.nn as nn
import torch.nn.functional as F
from net.Layers import Residual_SE
from utils.img_transforms import rgb2ycbcr, dct_2d
from net.vgg.RGBEncoder_VGGnet import VGGnet as RGBEncoder


def img_crop_P(img, P):
    B, _, H, W = img.shape
    h_stride = H // P
    w_stride = W // P
    batch_list = []
    for batch in range(B):
        patch_list = []
        for i in range(P):
            for j in range(P):
                patch_list.append(
                    img[batch, :, :, :][:, i * h_stride: (i + 1) * h_stride, :][:, :, j * w_stride: (j + 1) * w_stride])
        patchs = torch.cat(patch_list, dim=0).unsqueeze(0)
        batch_list.append(patchs)
    batchs = torch.cat(batch_list, dim=0)
    return batchs


def pixel_wise_channel_reshape_by_tensor_splicing(input_x, img_channel, P):
    """
    summary(model, input_size=(16, 3, 256, 256), device='cpu')
    1.1186094284057617 s
    """
    B, _, H, W = input_x.shape
    patch_size = (H // P, W // P)   # 此时 H = 原图H * 2 // 8，H // 4 即为 原图H // 32
    batch_list = []
    for batch in range(B):
        feature_list = []
        for rgb_channel in range(img_channel):
            for i in range(H // patch_size[0]):
                for j in range(W // patch_size[1]):
                    row_list = []
                    for m in range(P):
                        row_list.append(torch.hstack(tuple(input_x[batch, rgb_channel::img_channel,
                                            i*patch_size[0]: (i+1)*patch_size[0],
                                            j*patch_size[1]: (j+1)*patch_size[1]])[m*P: (m+1)*P]))
                    patch_feature = torch.vstack(tuple(row_list))
                    feature_list.append(patch_feature.reshape(1, 1, patch_feature.shape[0], patch_feature.shape[1]))
        batch_list.append(torch.cat(feature_list, dim=1))
    return torch.cat(batch_list, dim=0)


class FreqEncoder(nn.Module):
    """
    AFS 输出特征图大小为 P * patch_size
    AFS 输出通道数为 (img_size * 2 // P // patch_size) * (img_size * 2 // P // patch_size) * 3
    """
    def __init__(self, model='vgg16_bn', stage1_channel=64):
        super(FreqEncoder, self).__init__()

        '''手动设定参数'''
        # self.K = 192
        # self.P = 8
        # self.scale_factor = 4

        self.K = 48
        self.P = 4
        self.scale_factor = 2
        ''''''
        self.channel_norm_layer = nn.InstanceNorm2d(self.K, momentum=.0)
        self.se = Residual_SE(input_channels=self.K, reduction=16)
        self.transition_layer = nn.Sequential(
            nn.Conv2d(self.K, stage1_channel, kernel_size=1, stride=1, bias=False),
            nn.BatchNorm2d(stage1_channel)
        )
        self.freq_extractor = RGBEncoder(model=model, has_first_layer=False)

    def forward(self, x):
        # pre-processing
        # RGB to YCrCb
        x = rgb2ycbcr(x)
        # upsampling 2/1
        x = F.interpolate(x, scale_factor=self.scale_factor, mode='bilinear', recompute_scale_factor=True,
                          align_corners=True)
        # Crop P*P 2/P
        x = img_crop_P(x, P=self.P)     # torch.Size([B, K, 2H/P, 2W/P])
        # print('Crop:', x.shape)
        # DCT transform
        x = dct_2d(x)  # torch.Size([B, K, 2H/P, 2W/P])
        # print('DCT:', x.shape)
        # Reshape P*patch_size/1
        x = pixel_wise_channel_reshape_by_tensor_splicing(x, img_channel=3, P=self.P)  # torch.Size([B, K, 2H/P, 2W/P])
        # print('Reshape:', x.shape)
        # channel-wise Normalize
        x = self.channel_norm_layer(x)   # torch.Size([B, K, 2H/P, 2W/P])
        # print('Normalize:', x.shape)

        # SE block
        x = self.se(x)     # torch.Size([B, K, scale_factor * H /P, scale_factor * W/P])

        # trainsition layer
        x = self.transition_layer(x)  # torch.Size([B, stage1_channel, 2H/P, 2W/P])

        # RGB-encoder
        out1, out2, out3, out4, out5 = self.freq_extractor(x)

        # print(out1.shape)
        # print(out2.shape)
        # print(out3.shape)
        # print(out4.shape)
        # print(out5.shape)
        return out1, out2, out3, out4, out5


if __name__ == '__main__':
    from torchinfo import summary

    img_size = (256, 256)
    model = FreqEncoder(stage1_channel=64)
    summary(model, input_size=(1, 3, img_size[0], img_size[1]), device='cpu')

    '''
    AFS 输出特征图大小为 P * patch_size
    AFS 输出通道数为 (img_size * 2 // P // patch_size) * (img_size * 2 // P // patch_size) * 3
    1,769,472
    1,769,472
    '''