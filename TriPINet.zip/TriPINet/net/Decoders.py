import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision.transforms as T
from net.Layers import SqueezeExcitation, MSCA
import numpy as np


class Decoder_Net(nn.Module):
    def __init__(self, stage_channels, out_channel=1, skip_connection=True):
        super(Decoder_Net, self).__init__()
        self.out_channel = out_channel
        self.skip_connection = skip_connection

        self.input_channel = stage_channels[4]
        self.channel1 = stage_channels[3]
        self.channel2 = stage_channels[2]
        self.channel3 = stage_channels[1]
        self.channel4 = stage_channels[0]
        self.channel5 = self.channel4 // 2

        self.relu = nn.ReLU()
        self.up = nn.UpsamplingBilinear2d(scale_factor=2)

        '''input: 1/32'''

        '''stage w dilation #1'''  # output: 1/16
        self.stage1 = nn.Sequential(
            nn.Conv2d(self.input_channel, out_channels=self.channel1, kernel_size=3, stride=1, dilation=2,
                      padding=2, bias=False),
            nn.BatchNorm2d(self.channel1),
            self.relu,
            self.up
        )

        '''stage w dilation #2'''  # output: 1/8
        self.stage2 = nn.Sequential(
            nn.Conv2d(self.channel1, out_channels=self.channel2, kernel_size=3, stride=1, dilation=2,
                      padding=2, bias=False),
            nn.BatchNorm2d(self.channel2),
            self.relu,
            self.up
        )

        '''stage #3'''  # output: 1/4
        self.stage3 = nn.Sequential(
            nn.Conv2d(self.channel2, out_channels=self.channel3, kernel_size=1, stride=1, bias=False),
            nn.BatchNorm2d(self.channel3),
            self.relu,
            self.up
        )

        '''stage #4'''  # output: 1/2
        self.stage4 = nn.Sequential(
            nn.Conv2d(self.channel3, out_channels=self.channel4, kernel_size=1, stride=1, bias=False),
            nn.BatchNorm2d(self.channel4),
            self.relu,
            self.up
        )

        '''stage #5'''  # output: 1/1
        self.stage5 = nn.Sequential(
            nn.Conv2d(self.channel4, out_channels=self.channel5, kernel_size=1, stride=1, bias=False),
            nn.BatchNorm2d(self.channel5),
            self.relu,
            self.up
        )

        '''output layer'''  # output: 1/1
        self.conv_last = nn.Conv2d(self.channel5, out_channels=self.out_channel, kernel_size=1, stride=1,
                                   padding=0, bias=True)

        '''参数初始化'''
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_in', nonlinearity='relu')

    def forward(self, x):
        # x: encoder stage output: (out1, out2, out3, out4, out5)
        if self.skip_connection:
            out1 = self.stage1(x[-1])
            out2 = self.stage2(out1 + x[3])
            out3 = self.stage3(out2 + x[2])
            out4 = self.stage4(out3 + x[1])
            out5 = self.stage5(out4 + x[0])
        else:
            out1 = self.stage1(x[-1])
            out2 = self.stage2(out1)
            out3 = self.stage3(out2)
            out4 = self.stage4(out3)
            out5 = self.stage5(out4)

        logits = self.conv_last(out5)
        return out1, out2, out3, out4, logits


class Decoder_SENet(nn.Module):
    def __init__(self, stage_channels, out_channel=1, skip_connection=True, SEBlock=SqueezeExcitation):
        super(Decoder_SENet, self).__init__()
        self.out_channel = out_channel
        self.skip_connection = skip_connection

        self.input_channel = stage_channels[4]
        self.channel1 = stage_channels[3]
        self.channel2 = stage_channels[2]
        self.channel3 = stage_channels[1]
        self.channel4 = stage_channels[0]
        self.channel5 = self.channel4 // 2

        self.relu = nn.ReLU()
        self.up = nn.UpsamplingBilinear2d(scale_factor=2)

        '''SEBlock'''
        if SEBlock.__name__ == 'SqueezeExcitation' or 'Residual_SE':
            self.se1 = SEBlock(input_channels=self.input_channel, reduction=16, pool='avgpool')
            self.se2 = SEBlock(input_channels=self.channel1, reduction=16, pool='avgpool')
            self.se3 = SEBlock(input_channels=self.channel2, reduction=16, pool='avgpool')
            self.se4 = SEBlock(input_channels=self.channel3, reduction=16, pool='maxpool')
            self.se5 = SEBlock(input_channels=self.channel4, reduction=16, pool='maxpool')
            # self.se5 = SEBlock(input_channels=self.channel4, reduction=16, pool='maxpool')
        elif SEBlock.__name__ == 'MSCA':
            self.se1 = MSCA(in_channel=self.input_channel, kernel_size=(3, 5, 7))
            self.se2 = MSCA(in_channel=self.channel1, kernel_size=(3, 5, 7))
            self.se3 = MSCA(in_channel=self.channel2, kernel_size=(3, 5, 7))
            self.se4 = MSCA(in_channel=self.channel3, kernel_size=(3, 5, 7))
            self.se5 = MSCA(in_channel=self.channel4, kernel_size=(3, 5, 7))

        '''input: 1/32'''

        '''stage w dilation #1'''  # output: 1/16
        self.stage1 = nn.Sequential(
            self.se1,
            # nn.Conv2d(self.input_channel, out_channels=self.channel1, kernel_size=3, stride=1, dilation=2,
            #           padding=2, bias=False),
            nn.Conv2d(self.input_channel, out_channels=self.channel1, kernel_size=1, stride=1, bias=False),
            nn.BatchNorm2d(self.channel1),
            self.relu,
            self.up
        )

        '''stage w dilation #2'''  # output: 1/8
        self.stage2 = nn.Sequential(
            self.se2,
            # nn.Conv2d(self.channel1, out_channels=self.channel2, kernel_size=3, stride=1, dilation=2,
            #           padding=2, bias=False),
            nn.Conv2d(self.channel1, out_channels=self.channel2, kernel_size=1, stride=1, bias=False),
            nn.BatchNorm2d(self.channel2),
            self.relu,
            self.up
        )

        '''stage #3'''  # output: 1/4
        self.stage3 = nn.Sequential(
            self.se3,
            nn.Conv2d(self.channel2, out_channels=self.channel3, kernel_size=1, stride=1, bias=False),
            nn.BatchNorm2d(self.channel3),
            self.relu,
            self.up
        )

        '''stage #4'''  # output: 1/2
        self.stage4 = nn.Sequential(
            self.se4,
            nn.Conv2d(self.channel3, out_channels=self.channel4, kernel_size=1, stride=1, bias=False),
            nn.BatchNorm2d(self.channel4),
            self.relu,
            self.up
        )

        '''stage #5'''  # output: 1/1
        self.stage5 = nn.Sequential(
            self.se5,
            nn.Conv2d(self.channel4, out_channels=self.channel5, kernel_size=1, stride=1, bias=False),
            nn.BatchNorm2d(self.channel5),
            self.relu,
            self.up
        )

        '''output layer'''  # output: 1/1
        self.conv_last = nn.Conv2d(self.channel5, out_channels=self.out_channel, kernel_size=1, stride=1,
                                   padding=0, bias=True)

        '''参数初始化'''
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_in', nonlinearity='relu')

    def forward(self, x):
        # x: encoder stage output: (out1, out2, out3, out4, out5)
        if self.skip_connection:
            out1 = self.stage1(x[-1])
            out2 = self.stage2(out1 + x[3])
            out3 = self.stage3(out2 + x[2])
            out4 = self.stage4(out3 + x[1])
            out5 = self.stage5(out4 + x[0])
        else:
            out1 = self.stage1(x[-1])
            out2 = self.stage2(out1)
            out3 = self.stage3(out2)
            out4 = self.stage4(out3)
            out5 = self.stage5(out4)

        logits = self.conv_last(out5)
        return out1, out2, out3, out4, logits


class Decoder_DenseNet(nn.Module):
    def __init__(self, input_channel=512, out_channel=1):
        super(Decoder_DenseNet, self).__init__()
        self.out_channel = out_channel

        self.input_channel = input_channel  # 512
        self.channel_div_2 = self.input_channel // 2  # 256
        self.channel_div_4 = self.input_channel // 4  # 128
        self.channel_div_8 = self.input_channel // 8  # 64
        self.channel_div_16 = self.input_channel // 16  # 32

        self.relu = nn.ReLU()

        '''input: 1/16'''

        '''de_conv #1'''  # output: 1/8
        self.deconv1 = nn.ConvTranspose2d(in_channels=self.input_channel, out_channels=self.channel_div_2,
                                          kernel_size=4, stride=2,
                                          padding=1)
        self.norm1_deconv = nn.BatchNorm2d(self.channel_div_2)

        '''Densely block1 '''  # output: 1/8
        self.conv11 = nn.Conv2d(self.channel_div_2, out_channels=self.channel_div_2, kernel_size=3, stride=1,
                                padding=1, bias=True)
        self.norm11 = nn.BatchNorm2d(self.channel_div_2)
        self.conv12 = nn.Conv2d(self.channel_div_2 * 2, out_channels=self.channel_div_2, kernel_size=3, stride=1,
                                padding=1, bias=True)
        self.norm12 = nn.BatchNorm2d(self.channel_div_2)
        self.block1_transition = nn.Conv2d(self.channel_div_2 * 3, out_channels=self.channel_div_2, kernel_size=1,
                                           stride=1, padding=0, bias=True)

        '''de_conv #2'''  # output: 1/4
        self.deconv2 = nn.ConvTranspose2d(in_channels=self.channel_div_2, out_channels=self.channel_div_4,
                                          kernel_size=4, stride=2,
                                          padding=1)
        self.norm2_deconv = nn.BatchNorm2d(self.channel_div_4)

        '''Densely block2 '''  # output: 1/4
        self.conv21 = nn.Conv2d(self.channel_div_4, out_channels=self.channel_div_4, kernel_size=3, stride=1,
                                padding=1, bias=True)
        self.norm21 = nn.BatchNorm2d(self.channel_div_4)
        self.conv22 = nn.Conv2d(self.channel_div_4 * 2, out_channels=self.channel_div_4, kernel_size=3, stride=1,
                                padding=1, bias=True)
        self.norm22 = nn.BatchNorm2d(self.channel_div_4)
        self.block2_transition = nn.Conv2d(self.channel_div_4 * 3, out_channels=self.channel_div_4, kernel_size=1,
                                           stride=1, padding=0, bias=True)

        '''de_conv #3'''  # output: 1/2
        self.deconv3 = nn.ConvTranspose2d(in_channels=self.channel_div_4, out_channels=self.channel_div_8,
                                          kernel_size=4, stride=2,
                                          padding=1)
        self.norm3_deconv = nn.BatchNorm2d(self.channel_div_8)

        '''Densely block3 '''  # output: 1/2
        self.conv31 = nn.Conv2d(self.channel_div_8, out_channels=self.channel_div_8, kernel_size=3, stride=1,
                                padding=1, bias=True)
        self.norm31 = nn.BatchNorm2d(self.channel_div_8)
        self.conv32 = nn.Conv2d(self.channel_div_8 * 2, out_channels=self.channel_div_8, kernel_size=3, stride=1,
                                padding=1, bias=True)
        self.norm32 = nn.BatchNorm2d(self.channel_div_8)
        self.block3_transition = nn.Conv2d(self.channel_div_8 * 3, out_channels=self.channel_div_8, kernel_size=1,
                                           stride=1, padding=0, bias=True)

        '''de_conv #4'''  # output: 1/1
        self.deconv4 = nn.ConvTranspose2d(in_channels=self.channel_div_8, out_channels=self.channel_div_16,
                                          kernel_size=4, stride=2,
                                          padding=1)
        self.norm4_deconv = nn.BatchNorm2d(self.channel_div_16)

        '''convolutional layer'''
        # same conv
        self.conv_last = nn.Conv2d(self.channel_div_16, out_channels=self.out_channel, kernel_size=5, stride=1,
                                   padding=2)

        '''参数初始化'''
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_in', nonlinearity='relu')
                # nn.init.constant_(m.bias, val=0)
            elif isinstance(m, nn.ConvTranspose2d):
                m.weight.data = self.bilinear_kernel(m.in_channels, m.out_channels, m.kernel_size[0])

    def bilinear_kernel(self, in_channels, out_channels, kernel_size):
        """
        return a bilinear filter tensor
        """
        factor = (kernel_size + 1) // 2
        if kernel_size % 2 == 1:
            center = factor - 1
        else:
            center = factor - 0.5
        og = np.ogrid[:kernel_size, :kernel_size]
        filt = (1 - abs(og[0] - center) / factor) * (1 - abs(og[1] - center) / factor)

        # 上半部分是生成一层双线性插值核
        # 下面是拉伸
        weight = np.zeros((in_channels, out_channels, kernel_size, kernel_size), dtype='float32')
        # 赋值到每一层
        weight[:, :] = filt
        return torch.from_numpy(weight)

    def forward(self, x):
        # de_conv #1
        out1_deconv = self.relu(self.norm1_deconv(self.deconv1(x)))

        # Densely block1
        d11 = self.relu(self.norm11(self.conv11(out1_deconv)))
        d12 = self.relu(self.norm12(self.conv12(torch.cat((out1_deconv, d11), dim=1))))
        out1 = self.block1_transition(torch.cat((out1_deconv, d11, d12), dim=1))

        # de_conv #2
        out2_deconv = self.relu(self.norm2_deconv(self.deconv2(out1)))

        # Densely block2
        d21 = self.relu(self.norm21(self.conv21(out2_deconv)))
        d22 = self.relu(self.norm22(self.conv22(torch.cat((out2_deconv, d21), dim=1))))
        out2 = self.block2_transition(torch.cat((out2_deconv, d21, d22), dim=1))

        # de_conv #3
        out3_deconv = self.relu(self.norm3_deconv(self.deconv3(out2)))

        # Densely block3
        d31 = self.relu(self.norm31(self.conv31(out3_deconv)))
        d32 = self.relu(self.norm32(self.conv32(torch.cat((out3_deconv, d31), dim=1))))
        out3 = self.block3_transition(torch.cat((out3_deconv, d31, d32), dim=1))

        # de_conv #4
        out4_deconv = self.relu(self.norm4_deconv(self.deconv4(out3)))

        # convolutional layer
        # reduce the checkerboard artifacts produced by the transposed convolutional layers
        logits = self.conv_last(out4_deconv)

        return logits


if __name__ == '__main__':
    from torchinfo import summary

    # Downloading: "https://download.pytorch.org/models/resnet50-19c8e357.pth" to C:\Users\CRRCOO/.cache\torch\hub\checkpoints\resnet50-19c8e357.pth
    # model = get_Netv1(sobel=True, n_input=3,  constrain=True)
    # summary(model, input_size=(16, 3, 256, 256), device='cpu')

    model = Decoder_SENet(stage_channels=[64, 64, 128, 256, 512])
    summary(model, input_size=((1, 64, 128, 128), (1, 64, 64, 64), (1, 128, 32, 32), (1, 256, 16, 16), (1, 512, 8, 8)),
            device='cpu')

    '''
    Input size (MB): 67.11
    Forward/backward pass size (MB): 0.00
    Params size (MB): 0.00
    Estimated Total Size (MB): 67.11
    '''
