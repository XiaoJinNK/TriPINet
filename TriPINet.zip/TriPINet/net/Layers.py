import torch
from torch import nn
import torch.nn.functional as F


class _PositionAttentionModule(nn.Module):
    """ Position attention module"""

    def __init__(self, in_channels, **kwargs):
        super(_PositionAttentionModule, self).__init__()
        self.conv_b = nn.Conv2d(in_channels, in_channels // 8, 1)
        self.conv_c = nn.Conv2d(in_channels, in_channels // 8, 1)
        self.conv_d = nn.Conv2d(in_channels, in_channels, 1)
        self.alpha = nn.Parameter(torch.zeros(1))
        self.softmax = nn.Softmax(dim=-1)

    def forward(self, x):
        batch_size, _, height, width = x.size()
        feat_b = self.conv_b(x).view(batch_size, -1, height * width).permute(0, 2, 1)
        feat_c = self.conv_c(x).view(batch_size, -1, height * width)
        attention_s = self.softmax(torch.bmm(feat_b, feat_c))
        feat_d = self.conv_d(x).view(batch_size, -1, height * width)
        feat_e = torch.bmm(feat_d, attention_s.permute(0, 2, 1)).view(batch_size, -1, height, width)
        out = self.alpha * feat_e + x

        return out


class _ChannelAttentionModule(nn.Module):
    """Channel attention module"""

    def __init__(self, **kwargs):
        super(_ChannelAttentionModule, self).__init__()
        self.beta = nn.Parameter(torch.zeros(1))
        self.softmax = nn.Softmax(dim=-1)

    def forward(self, x):
        batch_size, _, height, width = x.size()
        feat_a = x.view(batch_size, -1, height * width)
        feat_a_transpose = x.view(batch_size, -1, height * width).permute(0, 2, 1)
        attention = torch.bmm(feat_a, feat_a_transpose)
        attention_new = torch.max(attention, dim=-1, keepdim=True)[0].expand_as(attention) - attention
        attention = self.softmax(attention_new)

        feat_e = torch.bmm(attention, feat_a).view(batch_size, -1, height, width)
        out = self.beta * feat_e + x

        return out


class DualAttention(nn.Module):
    def __init__(self, in_channel, out_channel, norm_layer=nn.BatchNorm2d, norm_kwargs=None, **kwargs):
        super(DualAttention, self).__init__()

        inter_channels = in_channel // 4
        self.conv_p1 = nn.Sequential(
            nn.Conv2d(in_channel, inter_channels, 3, padding=1, bias=False),
            norm_layer(inter_channels, **({} if norm_kwargs is None else norm_kwargs)),
            nn.ReLU(True)
        )
        self.conv_c1 = nn.Sequential(
            nn.Conv2d(in_channel, inter_channels, 3, padding=1, bias=False),
            norm_layer(inter_channels, **({} if norm_kwargs is None else norm_kwargs)),
            nn.ReLU(True)
        )
        self.pam = _PositionAttentionModule(inter_channels, **kwargs)
        self.cam = _ChannelAttentionModule(**kwargs)
        self.conv_p2 = nn.Sequential(
            nn.Conv2d(inter_channels, inter_channels, 3, padding=1, bias=False),
            norm_layer(inter_channels, **({} if norm_kwargs is None else norm_kwargs)),
            nn.ReLU(True)
        )
        self.conv_c2 = nn.Sequential(
            nn.Conv2d(inter_channels, inter_channels, 3, padding=1, bias=False),
            norm_layer(inter_channels, **({} if norm_kwargs is None else norm_kwargs)),
            nn.ReLU(True)
        )
        self.out = nn.Sequential(
            nn.Dropout(0.1),
            nn.Conv2d(inter_channels, out_channel, 1)
        )

    def forward(self, x):
        feat_p = self.conv_p1(x)
        feat_p = self.pam(feat_p)
        feat_p = self.conv_p2(feat_p)  # torch.Size([B, 1024, 16, 16])

        feat_c = self.conv_c1(x)
        feat_c = self.cam(feat_c)
        feat_c = self.conv_c2(feat_c)  # torch.Size([B, 1024, 16, 16])

        feat_fusion = feat_p + feat_c  # torch.Size([B, 1024, 16, 16])
        fusion_out = self.out(feat_fusion)  # torch.Size([B, 2048, 16, 16])

        return fusion_out


class SELayer(nn.Module):
    """
    SE with Fully Connected Layer(nn.Linear)
    """
    def __init__(self, in_channel, reduction=16):
        super(SELayer, self).__init__()
        self.avgpool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Sequential(
            nn.Linear(in_channel, in_channel // reduction, bias=False),
            nn.ReLU(inplace=True),
            nn.Linear(in_channel // reduction, in_channel, bias=False),
            nn.Sigmoid()
        )

    def forward(self, x):
        b, c, h, w = x.size()
        y = self.avgpool(x).view(b, c)
        y = self.fc(y).view(b, c, 1, 1)
        return x * y.expand_as(x)


class SqueezeExcitation(nn.Module):
    """
    【torchvision.ops.SqueezeExcitation 官方实现】
    This block implements the Squeeze-and-Excitation block from https://arxiv.org/abs/1709.01507 (see Fig. 1).
    Parameters ``activation``, and ``scale_activation`` correspond to ``delta`` and ``sigma`` in in eq. 3.

    Args:
        input_channels (int): Number of channels in the input image
        squeeze_channels (int): Number of squeeze channels
        activation (Callable[..., torch.nn.Module], optional): ``delta`` activation. Default: ``torch.nn.ReLU``
        scale_activation (Callable[..., torch.nn.Module]): ``sigma`` activation. Default: ``torch.nn.Sigmoid``
    """

    def __init__(
            self,
            input_channels: int,
            reduction: int = 16,
            activation=nn.ReLU,
            scale_activation=nn.Sigmoid,
            pool='avgpool'
    ):
        super(SqueezeExcitation, self).__init__()

        if pool == 'avgpool':
            self.pool = nn.AdaptiveAvgPool2d(1)
        elif pool == 'maxpool':
            self.pool = nn.AdaptiveMaxPool2d(1)
        else:
            print('Parameter pool is not avgpool or maxpool')
            return
        self.fc1 = nn.Conv2d(input_channels, input_channels // reduction, 1)
        self.fc2 = nn.Conv2d(input_channels // reduction, input_channels, 1)
        self.activation = activation()
        self.scale_activation = scale_activation()

    def _scale(self, input):
        scale = self.pool(input)
        scale = self.fc1(scale)
        scale = self.activation(scale)
        scale = self.fc2(scale)
        return self.scale_activation(scale)

    def forward(self, input):
        scale = self._scale(input)
        return scale * input


class ACF(nn.Module):
    def __init__(self, f_in_channel, r_in_channel):
        super(ACF, self).__init__()

        self.f_conv = nn.Conv2d(in_channels=f_in_channel + r_in_channel, out_channels=1, kernel_size=1)
        self.r_conv = nn.Conv2d(in_channels=f_in_channel + r_in_channel, out_channels=1, kernel_size=1)

    def forward(self, f, r):
        x = torch.cat((f, r), dim=1)
        Gf = self.f_conv(x)
        Gr = self.r_conv(x)
        Af = torch.exp(Gf) / (torch.exp(Gf) + torch.exp(Gr))
        Ar = torch.exp(Gr) / (torch.exp(Gf) + torch.exp(Gr))
        outf = Af * f
        outr = Ar * r
        return outf + outr


class BayarConv2d(nn.Module):
    """
    [2021 ICCV] Image Manipulation Detection by Multi-View Multi-Scale Supervision
    参考代码：https://github.com/dong03/MVSS-Net
    """

    def __init__(self, in_channels, out_channels, kernel_size=5, stride=1, padding=0):
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.kernel_size = kernel_size
        self.stride = stride
        self.padding = padding
        self.minus1 = (torch.ones(self.in_channels, self.out_channels, 1) * -1.000)

        super(BayarConv2d, self).__init__()
        # only (kernel_size ** 2 - 1) trainable params as the center element is always -1
        self.kernel = nn.Parameter(torch.rand(self.in_channels, self.out_channels, kernel_size ** 2 - 1),
                                   requires_grad=True)

    def bayarConstraint(self):
        self.kernel.data = self.kernel.permute(2, 0, 1)
        self.kernel.data = torch.div(self.kernel.data, self.kernel.data.sum(0))
        self.kernel.data = self.kernel.permute(1, 2, 0)
        ctr = self.kernel_size ** 2 // 2
        real_kernel = torch.cat((self.kernel[:, :, :ctr], self.minus1.to(self.kernel.device), self.kernel[:, :, ctr:]),
                                dim=2)
        real_kernel = real_kernel.reshape((self.out_channels, self.in_channels, self.kernel_size, self.kernel_size))
        return real_kernel

    def forward(self, x):
        x = F.conv2d(x, self.bayarConstraint(), stride=self.stride, padding=self.padding)
        return x


class SRMConv2d(nn.Module):
    """
    SRM (Steganalysis Rich Model)
    [2018 CVPR] Learning Rich Features for Image Manipulation Detection
    [2019 CVPR] ManTra-Net_Manipulation Tracing Network For Detection And Localization of Image Forgeries with
                Anomalous Features
    参考代码：https://github.com/BoisV/MantraNet_pytorch/blob/main/models/network.py
    """
    def __init__(self, in_channels, out_channels, stride=1, padding=2):
        super(SRMConv2d, self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.stride = stride
        self.padding = padding
        self.SRMWeights = nn.Parameter(
            self._get_srm_list(), requires_grad=False)

    def _get_srm_list(self):
        # srm kernel 1
        srm1 = [[0,  0, 0,  0, 0],
                [0, -1, 2, -1, 0],
                [0,  2, -4, 2, 0],
                [0, -1, 2, -1, 0],
                [0,  0, 0,  0, 0]]
        srm1 = torch.tensor(srm1, dtype=torch.float32) / 4.

        # srm kernel 2
        srm2 = [[-1, 2, -2, 2, -1],
                [2, -6, 8, -6, 2],
                [-2, 8, -12, 8, -2],
                [2, -6, 8, -6, 2],
                [-1, 2, -2, 2, -1]]
        srm2 = torch.tensor(srm2, dtype=torch.float32) / 12.

        # srm kernel 3
        srm3 = [[0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0],
                [0, 1, -2, 1, 0],
                [0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0]]
        srm3 = torch.tensor(srm3, dtype=torch.float32) / 2.

        return torch.stack([torch.stack([srm1, srm1, srm1], dim=0), torch.stack([srm2, srm2, srm2], dim=0), torch.stack([srm3, srm3, srm3], dim=0)], dim=0)

    def forward(self, X):
        return F.conv2d(X, self.SRMWeights, stride=self.stride, padding=self.padding)


class CMDA(nn.Module):
    """
    Cross Modality Dual Attention
    """

    def __init__(self, out_channel):
        super(CMDA, self).__init__()

        # spatial attention
        self.f_saconv = nn.Sequential(
            nn.Conv2d(out_channel * 2, out_channel, kernel_size=1, stride=1, padding=0, bias=True),
            # nn.BatchNorm2d(out_channel),
            # nn.ReLU(),
            nn.Conv2d(out_channel, 1, kernel_size=1, stride=1, bias=True)
        )
        self.n_saconv = nn.Sequential(
            nn.Conv2d(out_channel * 2, out_channel, kernel_size=1, stride=1, padding=0, bias=True),
            # nn.BatchNorm2d(out_channel),
            # nn.ReLU(),
            nn.Conv2d(out_channel, 1, kernel_size=1, stride=1, bias=True)
        )

        # channel attention
        self.f_caconv = nn.Sequential(
            nn.Conv2d(out_channel * 2, out_channel, kernel_size=1, stride=1, padding=0, bias=True),
            # nn.BatchNorm2d(out_channel),
            # nn.ReLU(),
            nn.AdaptiveAvgPool2d((1, 1))  # GAP
        )
        self.n_caconv = nn.Sequential(
            nn.Conv2d(out_channel * 2, out_channel, kernel_size=1, stride=1, padding=0, bias=True),
            # nn.BatchNorm2d(out_channel),
            # nn.ReLU(),
            nn.AdaptiveAvgPool2d((1, 1))  # GAP
        )

        # mid path
        self.mid_conv = nn.Sequential(
            nn.Conv2d(out_channel * 2, out_channel, kernel_size=1, stride=1, padding=0, bias=True),
            # nn.BatchNorm2d(out_channel),
            # nn.ReLU()
        )

    def forward(self, f, n):
        x = torch.cat((f, n), dim=1)
        # mid path
        out_mid = self.mid_conv(x)
        # spatial attention
        Gf = self.f_saconv(x)
        Gn = self.n_saconv(x)
        Af = torch.exp(Gf) / (torch.exp(Gf) + torch.exp(Gn))
        An = torch.exp(Gn) / (torch.exp(Gf) + torch.exp(Gn))
        outf = Af * f
        outn = An * n
        out_sa = outf + outn + out_mid
        # channel attention
        Gf = self.f_caconv(x)
        Gn = self.n_caconv(x)
        Af = torch.exp(Gf) / (torch.exp(Gf) + torch.exp(Gn))
        An = torch.exp(Gn) / (torch.exp(Gf) + torch.exp(Gn))
        outf = Af * f
        outn = An * n
        out_ca = outf + outn + out_mid

        return out_sa + out_ca


class CMTF(nn.Module):
    """
    Cross-Modality Triple attention feature Fusion
    input: (x, f, n),
        x: the first param x must be  RGB feature
        f, n: the last two feature will be CMDA fused
    """

    def __init__(self, out_channel):
        super(CMTF, self).__init__()

        self.cmda = CMDA(out_channel)

    def forward(self, x, f, n):
        fn = self.cmda(f, n)
        # SOD - Motion Guided Attention
        return fn * x + x


class CMTA(nn.Module):
    """
    Cross Modality Triple Attention
    """

    def __init__(self, out_channel):
        super(CMTA, self).__init__()

        # spatial attention
        # RGB
        self.r_saconv = nn.Sequential(
            nn.Conv2d(out_channel * 3, out_channel, kernel_size=3, stride=1, padding=1, bias=False),
            nn.BatchNorm2d(out_channel),
            nn.ReLU(),
            nn.Conv2d(out_channel, 1, kernel_size=1, stride=1, bias=True)
        )
        # Frequency
        self.f_saconv = nn.Sequential(
            nn.Conv2d(out_channel * 3, out_channel, kernel_size=3, stride=1, padding=1, bias=False),
            nn.BatchNorm2d(out_channel),
            nn.ReLU(),
            nn.Conv2d(out_channel, 1, kernel_size=1, stride=1, bias=True)
        )
        # Noise
        self.n_saconv = nn.Sequential(
            nn.Conv2d(out_channel * 3, out_channel, kernel_size=3, stride=1, padding=1, bias=False),
            nn.BatchNorm2d(out_channel),
            nn.ReLU(),
            nn.Conv2d(out_channel, 1, kernel_size=1, stride=1, bias=True)
        )

        # channel attention
        self.r_caconv = nn.Sequential(
            nn.Conv2d(out_channel * 3, out_channel, kernel_size=3, stride=1, padding=1, bias=False),
            nn.BatchNorm2d(out_channel),
            nn.ReLU(),
            nn.AdaptiveAvgPool2d((1, 1))  # GAP
        )
        self.f_caconv = nn.Sequential(
            nn.Conv2d(out_channel * 3, out_channel, kernel_size=3, stride=1, padding=1, bias=False),
            nn.BatchNorm2d(out_channel),
            nn.ReLU(),
            nn.AdaptiveAvgPool2d((1, 1))  # GAP
        )
        self.n_caconv = nn.Sequential(
            nn.Conv2d(out_channel * 3, out_channel, kernel_size=3, stride=1, padding=1, bias=False),
            nn.BatchNorm2d(out_channel),
            nn.ReLU(),
            nn.AdaptiveAvgPool2d((1, 1))  # GAP
        )

    def forward(self, r, f, n):
        x = torch.cat((r, f, n), dim=1)
        # spatial attention
        Gr = self.r_saconv(x)
        Gf = self.f_saconv(x)
        Gn = self.n_saconv(x)
        Ar = torch.exp(Gr) / (torch.exp(Gr) + torch.exp(Gf) + torch.exp(Gn))
        Af = torch.exp(Gf) / (torch.exp(Gr) + torch.exp(Gf) + torch.exp(Gn))
        An = torch.exp(Gn) / (torch.exp(Gr) + torch.exp(Gf) + torch.exp(Gn))
        outr = Ar * r
        outf = Af * f
        outn = An * n
        out_sa = outr + outf + outn
        # channel attention
        Gr = self.r_caconv(x)
        Gf = self.f_caconv(x)
        Gn = self.n_caconv(x)
        Ar = torch.exp(Gr) / (torch.exp(Gr) + torch.exp(Gf) + torch.exp(Gn))
        Af = torch.exp(Gf) / (torch.exp(Gr) + torch.exp(Gf) + torch.exp(Gn))
        An = torch.exp(Gn) / (torch.exp(Gr) + torch.exp(Gf) + torch.exp(Gn))
        outr = Ar * r
        outf = Af * f
        outn = An * n
        out_ca = outr + outf + outn

        return out_sa + out_ca


class MSCA(nn.Module):
    """
    Multi-Scale Channel Attention
    """

    def __init__(self, in_channel, kernel_size=(7, 15, 31)):
        super(MSCA, self).__init__()
        # (3, 1, 1)  (5, 1, 2)

        # identity stream
        self.se = SqueezeExcitation(input_channels=in_channel, reduction=4)

        # 1st stream
        self.conv1 = nn.Sequential(
            nn.Conv2d(in_channel, in_channel, kernel_size=kernel_size[0], stride=1,
                      padding=(kernel_size[0] - 1) // 2, bias=False),
            nn.BatchNorm2d(num_features=in_channel)
        )
        self.conv11 = nn.Sequential(
            nn.Conv2d(in_channel, in_channel, kernel_size=(1, kernel_size[0]), stride=(1, 1),
                      padding=(0, (kernel_size[0] - 1) // 2), bias=False),
            nn.BatchNorm2d(num_features=in_channel)
        )
        self.conv12 = nn.Sequential(
            nn.Conv2d(in_channel, in_channel, kernel_size=(kernel_size[0], 1), stride=(1, 1),
                      padding=((kernel_size[0] - 1) // 2, 0), bias=False),
            nn.BatchNorm2d(num_features=in_channel)
        )
        self.se1 = SqueezeExcitation(input_channels=in_channel, reduction=4)

        # 2nd stream
        self.conv2 = nn.Sequential(
            nn.Conv2d(in_channel, in_channel, kernel_size=kernel_size[1], stride=1,
                      padding=(kernel_size[1] - 1) // 2, bias=False),
            nn.BatchNorm2d(num_features=in_channel)
        )
        self.conv21 = nn.Sequential(
            nn.Conv2d(in_channel, in_channel, kernel_size=(1, kernel_size[1]), stride=(1, 1),
                      padding=(0, (kernel_size[1] - 1) // 2), bias=False),
            nn.BatchNorm2d(num_features=in_channel)
        )
        self.conv22 = nn.Sequential(
            nn.Conv2d(in_channel, in_channel, kernel_size=(kernel_size[1], 1), stride=(1, 1),
                      padding=((kernel_size[1] - 1) // 2, 0), bias=False),
            nn.BatchNorm2d(num_features=in_channel)
        )
        self.se2 = SqueezeExcitation(input_channels=in_channel, reduction=4)

        # 3rd stream
        self.conv3 = nn.Sequential(
            nn.Conv2d(in_channel, in_channel, kernel_size=kernel_size[2], stride=1,
                      padding=(kernel_size[2] - 1) // 2, bias=False),
            nn.BatchNorm2d(num_features=in_channel)
        )
        self.conv31 = nn.Sequential(
            nn.Conv2d(in_channel, in_channel, kernel_size=(1, kernel_size[2]), stride=(1, 1),
                      padding=(0, (kernel_size[2] - 1) // 2), bias=False),
            nn.BatchNorm2d(num_features=in_channel)
        )
        self.conv32 = nn.Sequential(
            nn.Conv2d(in_channel, in_channel, kernel_size=(kernel_size[2], 1), stride=(1, 1),
                      padding=((kernel_size[2] - 1) // 2, 0), bias=False),
            nn.BatchNorm2d(num_features=in_channel)
        )
        self.se3 = SqueezeExcitation(input_channels=in_channel, reduction=4)

    def forward(self, x):
        out = self.se(x)
        out1 = self.se1(self.conv1(x) + self.conv11(x) + self.conv12(x))
        out2 = self.se2(self.conv2(x) + self.conv21(x) + self.conv22(x))
        out3 = self.se3(self.conv3(x) + self.conv31(x) + self.conv32(x))
        return out + out1 + out2 + out3


class Residual_SE(nn.Module):
    def __init__(self, input_channels, reduction=16, pool='avgpool'):
        super(Residual_SE, self).__init__()
        self.se = SqueezeExcitation(input_channels=input_channels, reduction=reduction, pool=pool)

    def forward(self, x):
        return x + self.se(x)


if __name__ == '__main__':
    from torchinfo import summary

    t = torch.randn(size=(1, 32, 128, 128))

    # model = CMDA(out_channel=16)
    # summary(model, input_size=((8, 16, 128, 128), (8, 16, 128, 128)), device='cpu')

    # model = CMTF(out_channel=16)
    # summary(model, input_size=((8, 16, 128, 128), (8, 16, 128, 128), (8, 16, 128, 128)), device='cpu')

    # model = CMTA(out_channel=16)
    # summary(model, input_size=((8, 16, 128, 128), (8, 16, 128, 128), (8, 16, 128, 128)), device='cpu')
    #
    # print(model(t, t, t).shape)

    layer = nn.Conv2d(32, 32, kernel_size=(1, 9), stride=(1, 1),
                      padding=(0, (9 - 1) // 2))

    print(layer(t).shape)
